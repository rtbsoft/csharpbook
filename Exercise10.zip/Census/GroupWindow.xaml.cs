﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Census
{
    /// <summary>
    /// Interaction logic for GroupWindow.xaml
    /// </summary>
    public partial class GroupWindow : Window
    {
        public int GroupSize { get; set; }

        private readonly Regex digitsOnly = new Regex(@"^\d*$");

        public GroupWindow()
        {
            InitializeComponent();
        }



        private void OK_OnClick(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(Years.Text, out var years))
            {
                if (years > 0)
                {
                    GroupSize = years;
                    DialogResult = true;
                    Close();
                    return;
                }
            }

            MessageBox.Show("Invalid entry. Please try again.", "Census", MessageBoxButton.OK,
                MessageBoxImage.Asterisk);
            Years.Text = "";
        }

        private void Cancel_OnClick(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void Years_OnPreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !digitsOnly.IsMatch(e.Text);
        }
    }
}
