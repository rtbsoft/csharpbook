﻿using CsvHelper;

using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Census
{
    class VM: INotifyPropertyChanged
    {
        private List<Population> populations = new List<Population>();

        #region Properties
        public BindingList<Population> Populations { get; set; } = new BindingList<Population>();

        private bool ageSort = true;
        public bool AgeSort
        {
            get => ageSort;
            set { ageSort = value; OnPropertyChanged(); }
        }

        private bool maleSort = false;
        public bool MaleSort
        {
            get => maleSort;
            set { maleSort = value; OnPropertyChanged(); }
        }

        private bool femaleSort = false;
        public bool FemaleSort
        {
            get => femaleSort;
            set { femaleSort = value; OnPropertyChanged(); }
        }

        private bool totalSort = false;
        public bool TotalSort
        {
            get => totalSort;
            set { totalSort = value; OnPropertyChanged(); }
        }

        private double averageAge;
        public double AverageAge
        {
            get => averageAge;
            set { averageAge = value; OnPropertyChanged(); }
        }

        private double totalMale;
        public double TotalMale
        {
            get => totalMale;
            set { totalMale = value; OnPropertyChanged(); }
        }

        private double totalFemale;
        public double TotalFemale
        {
            get => totalFemale;
            set { totalFemale = value; OnPropertyChanged(); }
        }

        private double totalPopulation;
        public double TotalPopulation
        {
            get => totalPopulation;
            set { totalPopulation = value; OnPropertyChanged(); }
        }

        #endregion
        #region Methods
        public void Load(StreamReader sr)
        {
            using var csv = new CsvReader(sr, CultureInfo.InvariantCulture);
            populations = csv.GetRecords<Population>().ToList();

            populations.Sort((a, b) => a.Age - b.Age);

            TotalMale = 0;
            TotalFemale = 0;
            TotalPopulation = 0;
            AverageAge = 0;
            Populations.Clear();
            foreach (var p in populations)
            {
                Populations.Add(p);
                TotalMale += p.Male;
                TotalFemale += p.Female;
                TotalPopulation += p.Total;
                AverageAge += (p.Age + 0.5) * p.Total;
            }

            AverageAge /= TotalPopulation;
        }

        public void SortAge()
        {
            AgeSort = true;
            MaleSort = false;
            FemaleSort = false;
            TotalSort = false;

            populations.Sort((a, b) => a.Age - b.Age);

            Populations.Clear();
            foreach(var p in populations)
                Populations.Add(p);
        }

        public void SortMale()
        {
            MaleSort = true;
            AgeSort = false;
            FemaleSort = false;
            TotalSort = false;

            populations.Sort((a, b) => a.Male - b.Male);

            Populations.Clear();
            foreach(var p in populations)
                Populations.Add(p);
        }

        public void SortFemale()
        {
            FemaleSort = true;
            AgeSort = false;
            MaleSort = false;
            TotalSort = false;

            populations.Sort((a, b) => a.Female - b.Female);

            Populations.Clear();
            foreach(var p in populations)
                Populations.Add(p);
        }

        public void SortTotal()
        {
            TotalSort = true;
            AgeSort = false;
            MaleSort = false;
            FemaleSort = false;

            populations.Sort((a, b) => a.Total - b.Total);

            Populations.Clear();
            foreach(var p in populations)
                Populations.Add(p);
        }

        public void GroupBy(int count)
        {
            Populations.Clear();
            populations.Sort((a,b) => a.Age - b.Age);

            for (var i = 0; i < populations.Count; i++)
            {
                var groupIndex = i / count;
                if (Populations.Count == groupIndex + 1)
                {
                    Populations[groupIndex].Female += populations[i].Female;
                    Populations[groupIndex].Male += populations[i].Male;
                }
                else
                    Populations.Add(new Population{ Female = populations[i].Female, Male = populations[i].Male, Age = populations[i].Age });
            }
        }
        #endregion
        #region Property Changed
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
