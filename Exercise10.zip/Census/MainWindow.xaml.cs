﻿using Microsoft.Win32;

using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;

namespace Census
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly VM vm = new VM();

        public MainWindow()
        {
            InitializeComponent();
            DataContext = vm;

            addHotKey(Key.O, open_OnClick);
            addHotKey(Key.Q, quit_OnClick);
            addHotKey(Key.A, sortAge_OnClick);
            addHotKey(Key.M, sortMale_OnClick);
            addHotKey(Key.F, sortFemale_OnClick);
            addHotKey(Key.T, sortTotal_OnClick);
            addHotKey(Key.G, group_OnClick);
        }

        private void addHotKey(Key key, ExecutedRoutedEventHandler handler)
        {
            var cmd = new RoutedCommand();
            cmd.InputGestures.Add(new KeyGesture(key, ModifierKeys.Control));
            CommandBindings.Add(new CommandBinding(cmd , handler));
        }

        private void open_OnClick(object sender, RoutedEventArgs e)
        {
            try
            {
                var ofd = new OpenFileDialog
                {
                    Filter = "csv file (*.csv)|*.csv|All files (*.*)|*.*",
                    CheckFileExists = true,
                    CheckPathExists = true,
                    Title = "Open Census file"
                };

                if (ofd.ShowDialog() == true)
                {
                    using var sr = new StreamReader(ofd.FileName);
                    vm.Load(sr);
                }
            }
            catch
            {
                MessageBox.Show("Could not open file. Please try again.", "Census", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void quit_OnClick(object sender, RoutedEventArgs e)
        {
            if (verifyExit())
                Environment.Exit(0);
        }

        private void sortAge_OnClick(object sender, RoutedEventArgs e) => vm.SortAge();

        private void sortMale_OnClick(object sender, RoutedEventArgs e) => vm.SortMale();

        private void sortFemale_OnClick(object sender, RoutedEventArgs e) => vm.SortFemale();

        private void sortTotal_OnClick(object sender, RoutedEventArgs e) => vm.SortTotal();

        private void group_OnClick(object sender, RoutedEventArgs e)
        {
            var gw = new GroupWindow {Owner = this};
            if (gw.ShowDialog() == true)
                vm.GroupBy(gw.GroupSize);
        }

        private void MainWindow_OnClosing(object sender, CancelEventArgs e)
        {
            e.Cancel = !verifyExit();
        }

        private bool verifyExit()
        {
            return MessageBox.Show("Are you sure you want to quit?", "Census", MessageBoxButton.YesNo,
                MessageBoxImage.Question) == MessageBoxResult.Yes;
        }
    }
}
