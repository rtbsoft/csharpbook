﻿namespace TabularDataSample
{
    public enum ComboBoxOptions
    {
        Option1,
        Option2,
        Option3
    }

    public class Option
    {
        public ComboBoxOptions Id { get; set; }
        public string Description { get; set; }
    }
}
