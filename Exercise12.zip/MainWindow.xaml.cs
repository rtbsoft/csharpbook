﻿using System.Windows;

namespace TabularDataSample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        readonly VM vm = new();

        public MainWindow()
        {
            InitializeComponent();

            var oc = Application.Current.Resources["OptionSource"] as OptionCollection;
            oc.Add(new Option { Id = ComboBoxOptions.Option1, Description = "Option One" });
            oc.Add(new Option { Id = ComboBoxOptions.Option2, Description = "Option Two" });
            oc.Add(new Option { Id = ComboBoxOptions.Option3, Description = "Option Three" });
            Application.Current.Resources["OptionSource"] = oc;

            DataContext = vm;
        }

        private void DataGrid_Click(object sender, RoutedEventArgs e)
        {
            dg.Visibility = Visibility.Visible;
            lv.Visibility = Visibility.Hidden;
            lb.Visibility = Visibility.Hidden;
        }

        private void ListView_Click(object sender, RoutedEventArgs e)
        {
            dg.Visibility = Visibility.Hidden;
            lv.Visibility = Visibility.Visible;
            lb.Visibility = Visibility.Hidden;
        }

        private void ListBox_Click(object sender, RoutedEventArgs e)
        {
            dg.Visibility = Visibility.Hidden;
            lv.Visibility = Visibility.Visible;
            lb.Visibility = Visibility.Hidden;
        }
    }
}
