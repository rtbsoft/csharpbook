﻿using System;

namespace TabularDataSample
{
    public class Sample
    {
        public bool CheckBoxData { get; set; }
        public string TextData { get; set; }
        public ComboBoxOptions ComboBoxData { get; set; }
        public DateTime DateData { get; set; }
    }
}
