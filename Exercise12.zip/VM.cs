﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace TabularDataSample
{
    public class VM : INotifyPropertyChanged
    {
        public ObservableCollection<Sample> Samples { get; set; } = new ObservableCollection<Sample>()
        {
            new Sample {CheckBoxData = true, ComboBoxData = ComboBoxOptions.Option1, DateData = DateTime.Now, TextData = "This is a sample"},
            new Sample {CheckBoxData = true, ComboBoxData = ComboBoxOptions.Option2, DateData = DateTime.Now.AddDays(1), TextData = "This is a sample too"},
        };

        public BindingList<Option> Options { get; set; } = new()
        {
            new Option { Id = ComboBoxOptions.Option1, Description = "Option One" },
            new Option { Id = ComboBoxOptions.Option2, Description = "Option Two" },
            new Option { Id = ComboBoxOptions.Option3, Description = "Option Three" }
        };

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public class OptionCollection : ObservableCollection<Option>
    {
    }
}
