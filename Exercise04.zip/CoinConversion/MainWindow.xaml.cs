﻿using System.Windows;
using System.Windows.Controls;

namespace CoinConversion
{
    public partial class MainWindow : Window
    {
        //define constants for the various coin amounts
        const int NICKEL = 5;
        const int DIME = 10;
        const int QUARTER = 25;
        const int HALF_DOLLAR = 50;
        const int LOONIE = 100;
        const int TOONIE = 200;

        //remember the last time we got valid numbers
        string validAmount = "";

        public MainWindow()
        {
            InitializeComponent();
            //set the cursor to the Amount textbox on startup so the user
            //does not have to click there before starting to type
            Amount.Focus();
        }

        //rather than waiting for the user to press a button to cause our algorithm
        //to run and produce an output, we monitor the TextChange event on the textbox
        //this tells us whenever the user has typed something new. Whenever they have,
        //we can run our algorithm and display a new result
        private void Amount_TextChanged(object sender, TextChangedEventArgs e)
        {
            //get the trimmed arabic text and remember it
            string atxt = Amount.Text.Trim();
            //if the trimmed arabic doesn't match the original, remember we need to refresh the input textbox
            bool rewriteText = atxt != Amount.Text;

            //this is where we'll store the result of the parsing
            int value;

            //with if statements, we can use TryParse to determine whether the user provided
            //a valid number or not. If they did, then TryParse returns true and value contains
            //the parsed integer
            if (int.TryParse(atxt, out value) || atxt.Length == 0)
            {
                //remember this new valid text
                validAmount = atxt;
            }
            //if the text from before is a valid number
            else if (int.TryParse(validAmount, out value))
            {
                //we need to rewrite to get rid of the newly typed bad characters
                rewriteText = true;
            }
            //if neither is valid, we revert to an empty string
            else
            {
                validAmount = "";
                rewriteText = true;
            }

            //if we need to rewrite
            if (rewriteText)
            {
                //put back the last valid arabic numbers
                Amount.Text = validAmount;
                //adjust the caret to the end of the string
                Amount.SelectionStart = Amount.Text.Length;
                //stop any other code from processing the event
                e.Handled = true;
            }

            //calculate the coin string and display it
            displayCoins(value);
        }

        private void displayCoins(int value)
        {
            //this is where we'll put the result, if we calculated one
            string coins = string.Empty;

            //the solution is to use as many of the largest denomination coins as possible
            //before trying the next smaller coin, but only if the number provided is a multiple of 5
            //and less than 2000 cents
            if (value % 5 == 0 && value < 2000)
            {
                var toonies = value / TOONIE;
                if (toonies > 0)
                    coins += $"{toonies} toonie{(toonies == 1 ? "" : "s")}  ";
                value -= toonies * TOONIE;

                var loonies = value / LOONIE;
                if (loonies > 0)
                    coins += $"{loonies} loonie{(loonies == 1 ? "" : "s")}  ";
                value -= loonies * LOONIE;

                var halfDollars = value / HALF_DOLLAR;
                if (halfDollars > 0)
                    coins += $"{halfDollars} half dollar{(halfDollars == 1 ? "" : "s")}  ";
                value -= halfDollars * HALF_DOLLAR;

                var quarters = value / QUARTER;
                if (quarters > 0)
                    coins += $"{quarters} quarter{(quarters == 1 ? "" : "s")}  ";
                value -= quarters * QUARTER;

                var dimes = value / DIME;
                if (dimes > 0)
                    coins += $"{dimes} dime{(dimes == 1 ? "" : "s")}  ";
                value -= dimes * DIME;

                var nickels = value / NICKEL;
                if (nickels > 0)
                    coins += $"{nickels} nickel{(nickels == 1 ? "" : "s")}  ";
            }

            //if the user typed something
            if (Amount.Text.Length > 0)
            {
                //and the result is an empty string
                if (coins.Length == 0)
                    //tell the user what they've typed is invalid
                    coins = "Invalid number";
            }
            else
                //empty input converts to empty output
                coins = "";

            //set the display
            Coins.Text = coins;
        }
    }
}
