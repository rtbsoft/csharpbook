﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using CsvHelper;

namespace Census
{
    public enum SortBy
    {
        Age,
        Male,
        Female,
        Total
    }

    internal class VM : INotifyPropertyChanged
    {
        private List<Population> populations = new List<Population>();

        #region Properties

        public BindingList<Population> Populations { get; set; } = new BindingList<Population>();

        private SortBy sort = SortBy.Age;

        public SortBy Sort
        {
            get => sort;
            set
            {
                sort = value;
                OnPropertyChanged();
            }
        }

        private double averageAge;

        public double AverageAge
        {
            get => averageAge;
            set
            {
                averageAge = value;
                OnPropertyChanged();
            }
        }

        private double totalMale;

        public double TotalMale
        {
            get => totalMale;
            set
            {
                totalMale = value;
                OnPropertyChanged();
            }
        }

        private double totalFemale;

        public double TotalFemale
        {
            get => totalFemale;
            set
            {
                totalFemale = value;
                OnPropertyChanged();
            }
        }

        private double totalPopulation;

        public double TotalPopulation
        {
            get => totalPopulation;
            set
            {
                totalPopulation = value;
                OnPropertyChanged();
            }
        }

        #endregion

        #region Methods

        public void Load(StreamReader sr)
        {
            using var csv = new CsvReader(sr, CultureInfo.InvariantCulture);
            populations = csv.GetRecords<Population>().OrderBy(p => p.Age).ToList();

            TotalMale = populations.Sum(p => p.Male);
            TotalFemale = populations.Sum(p => p.Female);
            TotalPopulation = populations.Sum(p => p.Total);
            AverageAge = populations.Aggregate(0.0, (avg, p) => avg + (p.Age + 0.5) * p.Total / TotalPopulation);

            Populations.Clear();
            foreach (var p in populations)
                Populations.Add(p);
        }

        public void SortAge()
        {
            Sort = SortBy.Age;

            Populations.Clear();
            foreach (var p in populations.OrderBy(p => p.Age))
                Populations.Add(p);
        }

        public void SortMale()
        {
            Sort = SortBy.Male;

            Populations.Clear();
            foreach (var p in populations.OrderBy(p => p.Male))
                Populations.Add(p);
        }

        public void SortFemale()
        {
            Sort = SortBy.Female;

            Populations.Clear();
            foreach (var p in populations.OrderBy(p => p.Female))
                Populations.Add(p);
        }

        public void SortTotal()
        {
            Sort = SortBy.Total;

            Populations.Clear();
            foreach (var p in populations.OrderBy(p => p.Total))
                Populations.Add(p);
        }

        public void GroupBy(int count)
        {
            Populations.Clear();

            //use the GroupBy
            //the first parameter converts the age to which group it belongs to
            //second parameter is what part of the each object we want to play with (in this case, the whole thing)
            //third parameter allows us to create a new object from the grouped objects (found in grp)
            foreach (var p in populations.GroupBy(p => p.Age / count,
                q => q,
                (x, grp) => new Population
                {
                    Age = grp.Min(a => a.Age),
                    Female = grp.Sum(f => f.Female),
                    Male = grp.Sum(m => m.Male)
                }))
                Populations.Add(p);
        }

        #endregion

        #region Property Changed

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}