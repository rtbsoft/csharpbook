﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace Census
{
    public class SortByToBooleanConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value != null && parameter != null)
            {
                var curSort = (SortBy) value;

                var sortField = (string) parameter switch
                {
                    "Age" => SortBy.Age,
                    "Male" => SortBy.Male,
                    "Female" => SortBy.Female,
                    "Total" => SortBy.Total,
                    _ => SortBy.Age
                };

                return curSort == sortField;
            }

            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}