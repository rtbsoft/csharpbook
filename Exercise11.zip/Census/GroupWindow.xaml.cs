﻿using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;

namespace Census
{
    /// <summary>
    ///     Interaction logic for GroupWindow.xaml
    /// </summary>
    public partial class GroupWindow : Window
    {
        private readonly Regex digitsOnly = new Regex(@"^\d*$");

        public GroupWindow()
        {
            InitializeComponent();
        }

        public int GroupSize { get; set; }


        private void OK_OnClick(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(Years.Text, out var years))
                if (years > 0)
                {
                    GroupSize = years;
                    DialogResult = true;
                    Close();
                    return;
                }

            MessageBox.Show("Invalid entry. Please try again.", "Census", MessageBoxButton.OK,
                MessageBoxImage.Asterisk);
            Years.Text = "";
        }

        private void Cancel_OnClick(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void Years_OnPreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !digitsOnly.IsMatch(e.Text);
        }
    }
}