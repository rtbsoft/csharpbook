﻿namespace Census
{
    public class Population
    {
        public int Age { get; set; }
        public int Male { get; set; }
        public int Female { get; set; }
        public int Total => Male + Female;
    }
}