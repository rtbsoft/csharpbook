﻿using NorthWindOrders.ViewModels;

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace NorthWindOrders
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        const int ERROR_HEIGHT = 35;
        const int FILTER_HEIGHT = 220;
        const float ERROR_ANIMATION_TIME = 0.3f;
        const float FILTER_ANIMATION_TIME = 0.3f;

        private readonly OrderVM vm = OrderVM.Inst;
        private readonly DispatcherTimer errorTimer;
        private bool isErrorAnimating;
        private bool isFilterVisible;

        public MainWindow()
        {
            InitializeComponent();

            //initialize a one second timer for displaying any errors
            errorTimer = new DispatcherTimer();
            errorTimer.Tick += errorTimer_Tick;
            errorTimer.Interval = new TimeSpan(0, 0, 1);
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            await vm.Init();
            DataContext = vm;
        }

        private void errorTimer_Tick(object sender, EventArgs e)
        {
            //when the timer expires, minimize the error area by setting its height back to zero
            var anim = new DoubleAnimation(0, TimeSpan.FromSeconds(ERROR_ANIMATION_TIME));
            anim.Completed += (s, _) => isErrorAnimating = false;
            ErrorMessage.BeginAnimation(HeightProperty, anim);
            errorTimer.Stop();
        }

        private void errorAnimateStart(string message)
        {
            //set the error message and animate to maximize the error area
            isErrorAnimating = true;
            ErrorMessage.Content = message;
            var anim = new DoubleAnimation(ERROR_HEIGHT, TimeSpan.FromSeconds(ERROR_ANIMATION_TIME));
            anim.Completed += (s, _) => errorTimer.Start();
            ErrorMessage.BeginAnimation(HeightProperty, anim);
        }

        private void animateFilter()
        {
            //open or close the filter area by animation
            var anim = new DoubleAnimation(isFilterVisible ? 0 : FILTER_HEIGHT, TimeSpan.FromSeconds(FILTER_ANIMATION_TIME));
            anim.Completed += (s, _) => isFilterVisible = !isFilterVisible;
            FilterPanel.BeginAnimation(HeightProperty, anim);
        }

        //handle column header click in listview to sort by that column
        private void listView_Click(object sender, RoutedEventArgs e)
        {
            //the sender of the click is the ListView control, in general, so that doesn't help much
            //however, the e.OriginalSource is the column header that was clicked
            //we extract that and then get its name property
            //for convenience, the name of the column header is an exact match for the SortColumn enum names
            //that way, it is possible to parse the name into the enum directly.
            //it would also be possible to have a switch to convert from name to enum, if the names are not to your liking

            var column = (e.OriginalSource as GridViewColumnHeader)?.Name;
            if (column != null)
                vm.SortOrders((SortColumn)Enum.Parse(typeof(SortColumn), column));
        }

        //user clicks on filter button, animate it into the opposite state
        private void filter_Click(object sender, RoutedEventArgs e) => animateFilter();

        //user clicks 'add' button, create an OrderEdit window and show it as a modal dialog
        //we could also display it as a non-modal if we wanted to be able to edit/add/view more than one
        //order at a time. Depending on the workflow of the user, this might make sense to allow.
        private void add_Click(object sender, RoutedEventArgs e)
        {
            var oe = new OrderEditWindow
            {
                Owner = this,
                WindowStartupLocation = WindowStartupLocation.CenterOwner
            };

            //only display a message on error, since the user should be able to see the new item in the list
            oe.ShowDialog();
            if (oe.Result == false)
                errorAnimateStart("Something went wrong. Please try again.");
        }

        //user clicks the 'edit' button. Validate that there is a selected order. 
        private void edit_Click(object sender, RoutedEventArgs e)
        {
            //If not and we're not already animating to show an error, show this error
            if (!vm.HasSelectedOrder && !isErrorAnimating)
                errorAnimateStart("Select an order to edit first");
            else
            {
                //otherwise, show the edit window *with* a selected order
                var oe = new OrderEditWindow(vm.SelectedOrder)
                {
                    Owner = this,
                    WindowStartupLocation = WindowStartupLocation.CenterOwner
                };

                //only display a message on error, since the user should be able to see the changed item in the list
                oe.ShowDialog();
                if (oe.Result == false)
                    errorAnimateStart("Something went wrong. Please try again.");
            }
        }

        //user clicks the delete order button
        private async void delete_Click(object sender, RoutedEventArgs e)
        {
            //have to have something selected to delete
            if (!vm.HasSelectedOrder && !isErrorAnimating)
                errorAnimateStart("Select an order to delete first");
            else
            {
                //in this case, we're using a messageBox because we WANT the user to stop and confirm the action
                if (MessageBox.Show(this, "Are you sure you want to delete this order? This action cannot be undone.", "Northwind Orders",
                                    MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
                    if (!await vm.DeleteOrder())
                        errorAnimateStart("Something went wrong. Please try again.");
            }
        }

        //filtering action button handlers
        private void filterApply_Click(object sender, RoutedEventArgs e) => vm.ApplyFilterAndSort();

        private void filterClear_Click(object sender, RoutedEventArgs e) => vm.ClearFilter();

        private void filterSave_Click(object sender, RoutedEventArgs e)
        {
            vm.ApplyFilterAndSort();
            //auto close on save
            animateFilter();
        }
    }
}
