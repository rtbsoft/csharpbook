﻿using NorthWindOrders.Models;
using NorthWindOrders.ViewModels;

using System;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace NorthWindOrders.Converters
{
    public class EmployeeIdToEmployee : IValueConverter
    {
        //see CustomerIdToCustomer for a full discussion of why this is here
        private readonly OrderVM vm = OrderVM.Inst;

        //the combobox is provided a list of Employee objects, but the order object only has the Employee's Id
        //so we need to convert from the Id to the whole object 
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Employee e = null;

            if (value is int employeeId)
                e = vm.Employees.FirstOrDefault(e => e.Id == employeeId);

            return e;
        }

        //when the user changes the selection in the combobox, they are selecting new employee object
        //so we need to convert from the whole object to the Id for updating the Order object's field
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) 
            => (value as Employee)?.Id;
    }
}
