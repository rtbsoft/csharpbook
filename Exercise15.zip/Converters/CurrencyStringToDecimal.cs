﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace NorthWindOrders.Converters
{
    public class CurrencyStringToDecimal : IValueConverter
    {
        //either display the number formatted as currency or a blank field
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var d = value as decimal?;
            return d != null ? (d ?? 0).ToString("C", culture) : string.Empty;
        }

        //the default behavior of validation for a textbox bound to a decimal? property
        //causes it to fail to update the property if the user deletes all the text in the textbox
        //instead, we want to send back null. If not empty, then parse the string as currency.
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var s = value as string;
            return string.IsNullOrWhiteSpace(s) ? null : decimal.Parse(s, NumberStyles.Currency, culture);
        }
    }
}
