﻿using NorthWindOrders.Models;

using System.Collections.Generic;
using System.Threading.Tasks;

namespace NorthWindOrders.Repository
{
    //encapsulate the methods required for CRUD operations to the Customer table
    //add other methods as required
    //this may seem like overkill to have a separate class, but an application may have a hundred or more tables
    //all with all four operations -- putting them in one file results in a monster class that is difficult to
    //operate with. Start with this pattern and you will not need to refactor as the application grows.
    internal static class CustomerRepository
    {
        private const string SQL_SELECT_CUSTOMERS = "SELECT * FROM Customers";

        internal static async Task<List<Customer>> GetCustomers() => await Db.Inst.GetItems(SQL_SELECT_CUSTOMERS, dr => new Customer
        {
            Address = Db.GetDbString(dr, "Address"),
            City = Db.GetDbString(dr, "City"),
            CompanyName = Db.GetDbString(dr, "CompanyName"),
            ContactName = Db.GetDbString(dr, "ContactName"),
            ContactTitle = Db.GetDbString(dr, "ContactTitle"),
            Country = Db.GetDbString(dr, "Country"),
            Id = Db.GetDbString(dr, "CustomerID"),
            Fax = Db.GetDbString(dr, "Fax"),
            Phone = Db.GetDbString(dr, "Phone"),
            PostalCode = Db.GetDbString(dr, "PostalCode"),
            Region = Db.GetDbString(dr, "Region"),
        });
    }
}
