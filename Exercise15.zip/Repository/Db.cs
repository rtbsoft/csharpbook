﻿
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace NorthWindOrders.Repository
{
    //this class manages the connection to the database and provides some convenience methods for accessing it
    //because we have a connection open and, potentially, a transaction, implement the IDisposable interface
    //to ensure we clean that up
    internal class Db : IDisposable
    {
        #region constructor
        //manage connection and transaction objects
        private readonly SqlConnection conn;
        private SqlTransaction tran;

        //singleton class 
        public static Db Inst => db ??= new Db();

        private static Db db;
        //although there is an asynchronous version of Open, it can't be used in the constructor without adding .Wait
        //which blocks anyway.
        private Db() => (conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))?.Open();
        #endregion
        #region methods

        //wrap creating a command 
        //if it fails, let it throw an exception for the caller to handle
        internal async Task<SqlCommand> GetCommand(string commandText, bool isTransaction = false)
        {
            var cmd = new SqlCommand(commandText, conn);
            if (isTransaction)
            {
                if (tran == null)
                    tran = (SqlTransaction)await conn.BeginTransactionAsync();
                cmd.Transaction = tran;
            }
            return cmd;
        }

        //wrap creating a command
        //this version for when we can't or won't provide a commandText right away
        internal async Task<SqlCommand> GetCommand(bool isTransaction)
        {
            var cmd = new SqlCommand { Connection = conn };
            if (isTransaction)
            {
                if (tran == null)
                    tran = (SqlTransaction)await conn.BeginTransactionAsync();
                cmd.Transaction = tran;
            }
            return cmd;
        }

        //transaction wrappers
        internal void Commit()
        {
            tran?.Commit();
            tran?.Dispose();
            tran = null;
        }

        internal void Rollback()
        {
            tran?.Rollback();
            tran?.Dispose();
            tran = null;
        }

        //generic function to get items
        internal async Task<List<T>> GetItems<T>(string sql, Func<SqlDataReader, T> action, SqlParameter filter = null)
        {
            var items = new List<T>();

            try
            {
                using var cmd = await GetCommand(sql);

                if (filter != null)
                    cmd.Parameters.Add(filter);

                using var dr = await cmd.ExecuteReaderAsync();

                while (await dr.ReadAsync())
                    items.Add(action(dr));
                dr.Close();
            }
            catch
            {
                //don't give a partial list
                //if things have failed, then give nothing
                items.Clear();
            }

            return items;
        }

        //convenience methods for getting fields from a data reader
        //because the reader returns DBNull for fields with null values, we can't assign that directly to the property
        //instead, we need to check for it and convert the DBNull into a null
        internal static string GetDbString(SqlDataReader dr, string fieldName) => dr.IsDBNull(dr.GetOrdinal(fieldName)) ? null : dr.GetString(dr.GetOrdinal(fieldName));
        internal static int? GetDbInt(SqlDataReader dr, string fieldName) => dr.IsDBNull(dr.GetOrdinal(fieldName)) ? null : dr.GetInt32(dr.GetOrdinal(fieldName));
        internal static short? GetDbInt16(SqlDataReader dr, string fieldName) => dr.IsDBNull(dr.GetOrdinal(fieldName)) ? null : dr.GetInt16(dr.GetOrdinal(fieldName));
        internal static decimal? GetDbDecimal(SqlDataReader dr, string fieldName) => dr.IsDBNull(dr.GetOrdinal(fieldName)) ? null : dr.GetDecimal(dr.GetOrdinal(fieldName));
        internal static float? GetDbFloat(SqlDataReader dr, string fieldName) => dr.IsDBNull(dr.GetOrdinal(fieldName)) ? null : dr.GetFloat(dr.GetOrdinal(fieldName));
        internal static DateTime? GetDbDate(SqlDataReader dr, string fieldName) => dr.IsDBNull(dr.GetOrdinal(fieldName)) ? null : dr.GetDateTime(dr.GetOrdinal(fieldName));
        internal static bool? GetDbBool(SqlDataReader dr, string fieldName) => dr.IsDBNull(dr.GetOrdinal(fieldName)) ? null : dr.GetBoolean(dr.GetOrdinal(fieldName));
        public void Dispose()
        {
            conn?.Close();
            conn?.Dispose();
            tran?.Rollback();
            tran?.Dispose();
        }
        #endregion
    }

    //this class provides an extension method to SqlParameterCollection because the standard AddWithValue
    //throws an exception if we attempt to assign null to the parameter. What we need to do instead is to assign
    //DBNull.Value. So this method checks for null and converts it to a DBNull.Value.
    internal static class DbExtension
    {
        internal static SqlParameter AddWithValueNull(this SqlParameterCollection collection, string parameter, object value) 
            => collection.AddWithValue(parameter, value ?? DBNull.Value);
    }
}