﻿using System;

namespace NorthWindOrders.Models
{
    //we inherit from BindingObject so that when changes are made to the object (inside a BindingList or not),
    //the XAML will be notified of the change and display it

    //note that all the properties of the object (other than id) can be null!
    //this is not my doing, but reflecting the way the database is constructed
    //we should probably set up some kind of validation method in this object to call
    //before saving to the database, but what is required depends on the actual business
    //you could potentially have an anonymous customer arrive and pick up their own items
    //so all it would need is an Id and at least one OrderDetail object.
    public class Order : BindingObject
    {
        private int id;
        public int Id { get => id; set => SetField(ref id, value); }

        private string customerId;
        public string CustomerId { get => customerId; set => SetField(ref customerId, value); }

        private int? employeeId;
        public int? EmployeeId { get => employeeId; set => SetField(ref employeeId, value); }

        private DateTime? orderDate;
        public DateTime? OrderDate { get => orderDate; set => SetField(ref orderDate, value); }

        private DateTime? requiredDate;
        public DateTime? RequiredDate { get => requiredDate; set => SetField(ref requiredDate, value); }

        private DateTime? shippedDate;
        public DateTime? ShippedDate { get => shippedDate; set => SetField(ref shippedDate, value); }

        private int? shipperId;
        public int? ShipperId { get => shipperId; set => SetField(ref shipperId, value); }

        private string shipName;
        public string ShipName { get => shipName; set => SetField(ref shipName, value); }

        private string shipAddress;
        public string ShipAddress { get => shipAddress; set => SetField(ref shipAddress, value); }

        private string shipCity;
        public string ShipCity { get => shipCity; set => SetField(ref shipCity, value); }

        private string shipRegion;
        public string ShipRegion { get => shipRegion; set => SetField(ref shipRegion, value); }

        private string shipPostalCode;
        public string ShipPostalCode { get => shipPostalCode; set => SetField(ref shipPostalCode, value); }

        private string shipCountry;
        public string ShipCountry { get => shipCountry; set => SetField(ref shipCountry, value); }

        private decimal? subtotal;
        public decimal? Subtotal
        {
            get => subtotal;
            set
            {
                //make sure that total updates when the subtotal does
                if (SetField(ref subtotal, value))
                    OnPropertyChanged(nameof(Total));
            }
        }

        private decimal? freight;
        public decimal? Freight
        {
            get => freight;
            set
            {
                //make sure that total updates when the freight does
                if (SetField(ref freight, value))
                    OnPropertyChanged(nameof(Total));
            }
        }

        //calculate a total
        public decimal Total => (Subtotal ?? 0) + (Freight ?? 0);

        //make a copy of this object
        //this is only a shallow copy, but that's ok because we only have simple data types
        public Order Clone() => (Order)MemberwiseClone();

        //override the Equals so it checks only the Id
        public override bool Equals(object obj)
            => obj is Order o && o.Id == Id;

        //make the hashcode for this object the hashcode of the Id of this object
        public override int GetHashCode() => Id.GetHashCode();
    }
}
