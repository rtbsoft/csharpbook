﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace NorthWindOrders.Models
{
    //create an abstract class to encapsulate INotifyPropertyChanged behavior 
    //since we're using it in multiple places in this project
    //but we don't want to create an instance of this class, just allow its methods to be inherited
    public abstract class BindingObject : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null) 
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        //to save time while running, we do not want to notify XAML of changes if the same value 
        //was set for the property again, so we'll check for changes before notification
        protected bool SetField<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
        {
            var isSet = false;

            if (!EqualityComparer<T>.Default.Equals(field, value))
            {
                field = value;
                isSet = true;
                OnPropertyChanged(propertyName);
            }

            return isSet;
        }
    }
}
