﻿using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;

namespace Checkers
{
    //the checker square can have one of five states:
    //unoccupied, player1, player2, player1crowned, player2crowned
    //so we'll use an enum to track that
    public enum State
    {
        No,
        P1,
        P2,
        C1,
        C2
    }

    internal class VM : INotifyPropertyChanged
    {
        //specify the number of rows and columns
        public const int NUM_ROWS = 8;
        public const int NUM_COLS = 8;

        //specify the directory and file names for logging users actions
        private const string DIRNAME = "Checkers";
        private const string FILENAME = "log.txt";

        //variable to hold fully specified path to the log file
        private string filePath = "";

        public VM()
        {
            //when updating a global (to this file) variable
            //it is standard to neither pass it nor return it from the method
            //have the method update the global directly
            //we use a global so we only have to calculate this path once at the start
            //rather than every time we want to write the file
            calcFilePath();
        }

        //since the code uses a one dimensional index to figure out where the checkers
        //are located, we'll store their current positions in a one dimensional array
        public BindingList<State> States { get; set; } = new BindingList<State>
        {
            State.No, State.P1, State.No, State.P1, State.No, State.P1, State.No, State.P1,
            State.P1, State.No, State.P1, State.No, State.P1, State.No, State.P1, State.No,
            State.No, State.P1, State.No, State.P1, State.No, State.P1, State.No, State.P1,
            State.No, State.No, State.No, State.No, State.No, State.No, State.No, State.No,
            State.No, State.No, State.No, State.No, State.No, State.No, State.No, State.No,
            State.P2, State.No, State.P2, State.No, State.P2, State.No, State.P2, State.No,
            State.No, State.P2, State.No, State.P2, State.No, State.P2, State.No, State.P2,
            State.P2, State.No, State.P2, State.No, State.P2, State.No, State.P2, State.No
        };

        public BindingList<string> History { get; set; } = new BindingList<string>();

        public void HandleClick(int index)
        {
            //since we're now using this string twice, we're going to create a new variable
            //to hold the data, so we only need to calculate it once. If we decide later to change the message
            //we only need to update this one location as well.
            var msg = $"{index / NUM_COLS} {index % NUM_COLS} {States[index]}";

            //here is where we would add logic for moving pieces. For example,
            //we could say: if the user clicks a piece that matches the current turn 
            //then wait for another click. If that click is +1 row and either +/- 1 column
            //then it is a valid move and move it there. Or if it is +2 rows and either +/- 2 columns
            //then if there was an opposing piece at +1/+-1, then that is a valid move, move the
            //piece there and remove the opposing piece.
            //Crowned pieces can go forwards and backwards, so extend this same logic to them
            //NOTE: players are REQUIRED to take pieces if possible, so it is an invalid move
            //to move elsewhere when a piece can be taken.

            //but to verify that the binding updates properly, any click will toggle through the colors
            if (States[index] == State.No)
                States[index] = State.P1;
            //in this case, we need to manually notify the XAML that States has changed
            OnChange("States");

            //add to the listbox
            History.Add(msg);

            //add to the file
            updateFile(msg);
        }

        private void updateFile(string text)
        {
            //if something is wrong, we just don't log the data
            try
            {
                //if something went wrong with permissions, we may not have a valid filePath
                //make sure it is something before we try to use it
                if (!string.IsNullOrEmpty(filePath))
                    //note the linebreak character being added. If not, then all the events end up
                    //on the same line in the file
                    File.AppendAllText(filePath, $"{text}\n");
            }
            catch
            {
            }
        }

        private void calcFilePath()
        {
            //put this inside a try/catch because we may get into a situation where the user isn't allowed access to this file 
            //(Windows permissions, especially in a corporate environment, can be very restrictive)
            //depending on your specific requirements, you may chose to tell the user that you cannot log
            //and exit the application or, as in this case, silently fail and just not log anything. It depends
            //on your specific circumstances.
            try
            {
                //get the path to the special AppData folder for the current user
                var path = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                //add in our app's directory 
                path = Path.Combine(path, DIRNAME);
                //if it doesn't already exist, create it
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);

                //now add in the filename and save that whole thing to the global
                filePath = Path.Combine(path, FILENAME);
            }
            catch
            {
            }
        }

        #region Property Change

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnChange([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}