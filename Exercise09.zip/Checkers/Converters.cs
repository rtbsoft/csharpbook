﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace Checkers
{
    internal class StateToColorConverter : IValueConverter
    {
        private readonly SolidColorBrush noColor = new SolidColorBrush(Colors.Transparent);
        private readonly SolidColorBrush player1Color = new SolidColorBrush(Colors.Brown);
        private readonly SolidColorBrush player2Color = new SolidColorBrush(Colors.BurlyWood);

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var result = noColor;

            if (value != null)
            {
                var s = (State) value;

                result = s switch
                {
                    State.No => noColor,
                    State.P1 => player1Color,
                    State.P2 => player2Color,
                    _ => noColor
                };
            }

            return result;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}