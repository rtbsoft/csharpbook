﻿// Author: Rick Kozak

using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Checkers
{
    public partial class MainWindow : Window
    {
        private readonly VM vm = new VM();

        public MainWindow()
        {
            InitializeComponent();
            DataContext = vm;
        }

        //when all the internal prep work for the window is done, it will invoke this event
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //calculate the two board colors
            var darkBrush = new SolidColorBrush(Colors.RosyBrown);
            var lightBrush = new SolidColorBrush(Colors.Khaki);

            //keep track of which color to use
            var useDarkBrush = false;

            //for all the rows, add a row definition
            for (var row = 0; row < VM.NUM_ROWS; row++)
                CheckerGrid.RowDefinitions.Add(new RowDefinition());

            //for all the columns, add a column definition
            for (var col = 0; col < VM.NUM_COLS; col++)
                CheckerGrid.ColumnDefinitions.Add(new ColumnDefinition());

            //a nested for loop means that the inner code will be executed NUM_ROWS * NUM_COLS times
            for (var row = 0; row < VM.NUM_ROWS; row++)
            {
                for (var col = 0; col < VM.NUM_COLS; col++)
                {
                    //calculate a unique index for this button
                    var index = row * VM.NUM_COLS + col;
                    //create a checker image for the button
                    var viewbox = new Viewbox
                    {
                        Child = new Ellipse
                        {
                            Height = 1,
                            Width = 1
                        }
                    };
                    //bind the Fill property of the ellipse
                    //to a specific element of the VM class's States property 
                    var fillBinding = new Binding($"States[{index}]")
                    {
                        Converter = new StateToColorConverter()
                    };
                    BindingOperations.SetBinding(viewbox.Child, Shape.FillProperty, fillBinding);

                    //create the button
                    //we can set all the same properties here as we do in the XAML
                    var gridButton = new Button
                    {
                        Content = viewbox,
                        Margin = new Thickness(1),
                        Background = useDarkBrush ? darkBrush : lightBrush,
                        //the tag property is a special holder of any object we want to attach to the button
                        //we'll use this when the button is clicked
                        Tag = index
                    };

                    //specify the click event handler - same one for all buttons
                    gridButton.Click += gridButton_Click;

                    //do the equivalent of Grid.Row= and Grid.Column= in XAML
                    Grid.SetRow(gridButton, row);
                    Grid.SetColumn(gridButton, col);

                    //add it as a child of CheckerGrid
                    CheckerGrid.Children.Add(gridButton);

                    //toggle the boolean so we use the other color next time through the loop
                    useDarkBrush = !useDarkBrush;
                }

                //after every time the inner loop completes we need to check if we've done the loop and even or odd
                //number of times. If it is even, then we need to toggle one more time, or we won't get the alternating
                //pattern between rows.
                //but we don't need the test for a checkerboard, since we know it is even
                //if (VM.NUM_COLS % 2 == 0)
                    useDarkBrush = !useDarkBrush;
            }
        }

        private void gridButton_Click(object sender, RoutedEventArgs e)
        {
            //because all the buttons have the same click event handler,
            //we use the Tag property to identify which button was pressed
            var tag = (sender as Button)?.Tag;
            if (tag != null)
                vm.HandleClick((int) tag);
        }
    }
}