﻿// author: Rick Kozak

using System.Windows;
using System.Windows.Input;

namespace IceCreamCost
{
    public partial class MainWindow : Window
    {
        // use constants to give names to numbers and strings that do not change while the code is running
        const decimal CREAM_COST_PER_LITER = 5.50m;
        const decimal SUGAR_COST_PER_KG = 1.50m;
        const decimal EGG_COST_EACH = 0.25m;

        public MainWindow()
        {
            InitializeComponent();
        }

        // handle the clear button
        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            //set each of the 10 items to zero or empty string

            //note the spacing between the groups of things. It will be easier to
            //find things if they are grouped with some space around them
            
            //also note that each group is listed in the same order, again for ease of finding later

            CreamQty.Text = "0";
            SugarQty.Text = "0";
            EggQty.Text = "0";

            CreamPct.Content = "";
            SugarPct.Content = "";
            EggPct.Content = "";

            CreamAmount.Content = "";
            SugarAmount.Content = "";
            EggAmount.Content = "";

            Total.Content = "";
        }

        private void Calc_Click(object sender, RoutedEventArgs e)
        {
            // use a try/catch in case the user makes a mistake in number entry
            try
            {
                //convert the user's input into decimal numbers (we're working with money)
                decimal creamQty = decimal.Parse(CreamQty.Text);
                decimal sugarQty = decimal.Parse(SugarQty.Text);
                decimal eggQty = decimal.Parse(EggQty.Text);

                //calculate the cost of each item and the total
                decimal creamCost = creamQty * CREAM_COST_PER_LITER;
                decimal sugarCost = sugarQty * SUGAR_COST_PER_KG;
                decimal eggCost = eggQty * EGG_COST_EACH;
                decimal total = creamCost + sugarCost + eggCost;

                //calculate the percentages now that we have individual costs and the total
                decimal creamPct = creamCost / total;
                decimal sugarPct = sugarCost / total;
                decimal eggPct = eggCost / total;

                //update the user visible amounts (using the currency formatter C)
                CreamAmount.Content = creamCost.ToString("C");
                SugarAmount.Content = sugarCost.ToString("C");
                EggAmount.Content = eggCost.ToString("C");

                //update the user visible percentages
                //use the percent formatter P with a digit to indicate how many decimal places
                CreamPct.Content = creamPct.ToString("P1");
                SugarPct.Content = sugarPct.ToString("P1");
                EggPct.Content = eggPct.ToString("P1");

                Total.Content = total.ToString("C");
            }
            catch
            {
                //if anything goes wrong, show this message
                //note that if you set all quantities to zero, you will also get this message
                //that's because dividing by zero will also throw an exception and drop us down here
                MessageBox.Show("Please ensure all quantities are numeric values greater than zero");
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            //we can close the window (and the application) with this call
            Close();
        }

        //allow the user to move the window by clicking anywhere in the window (except inside the textboxes and buttons)
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // if the user tries to drag with the right mouse button, DragMove throws an exception
            // for now, we'll just swallow it and keep going
            try
            {
                DragMove();
            }
            catch { }
        }
    }
}
