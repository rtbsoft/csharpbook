﻿// Author: Rick Kozak

using System.Windows;
using System.Windows.Controls;

namespace Survey
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Other_Checked(object sender, RoutedEventArgs e)
        {
            //if other gender radio button is checked, then enable the combo
            //otherwise, disable it
            otherGenders.IsEnabled = other.IsChecked ?? false;
        }

        private void Process_Click(object sender, RoutedEventArgs e)
        {
            //default values for the three survey results
            string gender = "unknown";
            string musicStyle = "unknown";
            string listeningModes = "";

            //gender
            //use the coalescing (??) operator to merge the null state of the bool? type into the false state
            //this results in a bool type, which the if() is happy to process
            if (male.IsChecked ?? false)
                gender = "male";
            else if (female.IsChecked ?? false)
                gender = "female";
            else if (other.IsChecked ?? false)
            {
                //check to make sure the user picked something. A SelectedIndex of -1 means they didn't.
                if (otherGenders.SelectedIndex >= 0)
                    //get the content property of the ComboBoxItem
                    gender = (otherGenders.SelectedItem as ComboBoxItem).Content.ToString().ToLower();
            }

            //musical style
            //check to see the user picked something (this time, using the SelectedItem property
            if (musicStyles.SelectedItem != null)
                musicStyle = (musicStyles.SelectedItem as ListBoxItem).Content.ToString().ToLower();

            //listening modes
            //this time, convert the bool? using the equality operator
            //testing against true will produce a boolean result

            //sometimes, writing if statements on a single line can make things more readable
            //especially if the pattern repeats. It makes the pattern stand out and all of it
            //can be mentally digested more easily

            if (spotify.IsChecked == true) listeningModes += (listeningModes.Length != 0 ? ", " : "") + "spotify";
            if (apple.IsChecked == true) listeningModes += (listeningModes.Length != 0 ? ", " : "") + "apple";
            if (prime.IsChecked == true) listeningModes += (listeningModes.Length != 0 ? ", " : "") + "prime";
            if (xm.IsChecked == true) listeningModes += (listeningModes.Length != 0 ? ", " : "") + "xm";
            if (radio.IsChecked == true) listeningModes += (listeningModes.Length != 0 ? ", " : "") + "radio";
            if (lp.IsChecked == true) listeningModes += (listeningModes.Length != 0 ? ", " : "") + "lp";
            if (cd.IsChecked == true) listeningModes += (listeningModes.Length != 0 ? ", " : "") + "cd";
            if (ipod.IsChecked == true) listeningModes += (listeningModes.Length != 0 ? ", " : "") + "ipod";

            //only now can we assign a default value to listeningModes
            //since above, we were using the empty string to determine whether to add a comma or not
            if (string.IsNullOrEmpty(listeningModes))
                listeningModes = "unknown";
            else
            {
                //find the last comma and replace it with 'and' (no Oxford comma here :)
                int lastCommaIndex = listeningModes.LastIndexOf(',');
                //if there was a comma (if user selected only one, there would not be
                if (lastCommaIndex > 0)
                {
                    //take two parts of the string before and after the comma
                    string beforeComma = listeningModes.Substring(0, lastCommaIndex);
                    string afterComma = listeningModes.Substring(lastCommaIndex + 1);
                    //substitute the word 'and'
                    listeningModes = $"{beforeComma} and{afterComma}";
                }
            }

            //create a string to display
            results.Text = $"You identify as a {gender} who's favorite musical style is {musicStyle}. " +
                           $"You like listening using {listeningModes}.";
        }
    }
}
