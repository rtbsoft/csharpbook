﻿// Author: Rick Kozak

using System;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Exercise2
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AlternateUp_Click(object sender, RoutedEventArgs e)
        {
            //ensure the correct image is visible
            FixedImage.Visibility = Visibility.Hidden;
            AlternatingImage.Visibility = Visibility.Visible;
            //load an image by setting the source property in code
            //if you examine the project's bin/debug directory, you will see that 
            //the image files do not exist as separate entities. Instead, they are bundled into
            //the .exe file. Because of this, we need to create this special 'Uri' object
            //to identify the file inside the application that we want to turn into a BitmapImage object
            //that we can assign to the Source property of the Image control
            AlternatingImage.Source = new BitmapImage(new Uri("pack://application:,,,/thumbs up.png"));
        }

        private void AlternateDown_Click(object sender, RoutedEventArgs e)
        {
            FixedImage.Visibility = Visibility.Hidden;
            AlternatingImage.Visibility = Visibility.Visible;

            AlternatingImage.Source = new BitmapImage(new Uri("pack://application:,,,/thumbs down.png"));
        }

        private void VisibleUp_Click(object sender, RoutedEventArgs e)
        {
            FixedImage.Source = new BitmapImage(new Uri("pack://application:,,,/thumbs up.png"));
            FixedImage.Visibility = Visibility.Visible;

            AlternatingImage.Visibility = Visibility.Hidden;
        }

        private void VisibleDown_Click(object sender, RoutedEventArgs e)
        {
            AlternatingImage.Source = new BitmapImage(new Uri("pack://application:,,,/thumbs down.png"));
            AlternatingImage.Visibility = Visibility.Visible;

            FixedImage.Visibility = Visibility.Hidden;
        }
    }
}
