﻿// Author: Rick Kozak

using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Checkers
{
    public partial class MainWindow : Window
    {
        //specify the number of rows and columns
        private const int NUM_ROWS = 6;
        private const int NUM_COLS = 6;

        //specify the directory and file names for logging users actions
        private const string DIRNAME = "Checkers";
        private const string FILENAME = "log.txt";

        //variable to hold fully specified path to the log file
        private string filePath = "";

        public MainWindow()
        {
            InitializeComponent();
            //when updating a global (to this file) variable
            //it is standard to neither pass it nor return it from the method
            //have the method update the global directly
            //we use a global so we only have to calculate this path once at the start
            //rather than every time we want to write the file
            calcFilePath();
        }

        //when all the internal prep work for the window is done, it will invoke this event
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //calculate the two board colors
            var darkBrush = new SolidColorBrush(Colors.RosyBrown);
            var lightBrush = new SolidColorBrush(Colors.Khaki);

            //keep track of which color to use
            var useDarkBrush = true;

            //for all the rows, add a row definition
            for (var row = 0; row < NUM_ROWS; row++)
                CheckerGrid.RowDefinitions.Add(new RowDefinition());

            //for all the columns, add a column definition
            for (var col = 0; col < NUM_COLS; col++)
                CheckerGrid.ColumnDefinitions.Add(new ColumnDefinition());

            //a nested for loop means that the inner code will be executed NUM_ROWS * NUM_COLS times
            for (var row = 0; row < NUM_ROWS; row++)
            {
                for (var col = 0; col < NUM_COLS; col++)
                {
                    //calculate a unique index for this button
                    var index = row * NUM_COLS + col + 1;

                    //create the button
                    //we can set all the same properties here as we do in the XAML
                    var gridButton = new Button()
                    {
                        Content = $"{row},{col} ({index})",
                        Margin = new Thickness(1),
                        Background = useDarkBrush ? darkBrush : lightBrush,
                        //the tag property is a special holder of any object we want to attach to the button
                        //we'll use this when the button is clicked
                        Tag = index,
                    };

                    //specify the click event handler - same one for all buttons
                    gridButton.Click += gridButton_Click;

                    //do the equivalent of Grid.Row= and Grid.Column= in XAML
                    Grid.SetRow(gridButton, row);
                    Grid.SetColumn(gridButton, col);

                    //add it as a child of CheckerGrid
                    CheckerGrid.Children.Add(gridButton);

                    //toggle the boolean so we use the other color next time through the loop
                    useDarkBrush = !useDarkBrush;
                }

                //after every time the inner loop completes we need to check if we've done the loop and even or odd
                //number of times. If it is even, then we need to toggle one more time, or we won't get the alternating
                //pattern between rows.
                if (NUM_COLS % 2 == 0)
                    useDarkBrush = !useDarkBrush;
            }
        }

        private void gridButton_Click(object sender, RoutedEventArgs e)
        {
            //because all the buttons have the same click event handler, we need some way to distinguish them
            //the sender object is actually the button that was clicked
            //all we need to do is to cast it to a button
            var btn = sender as Button;

            //since we're now using this string twice, we're going to create a new variable
            //to hold the data, so we only need to calculate it once. If we decide later to change the message
            //we only need to update this one location as well.
            var msg = $"{btn.Content} {btn.Tag}";

            //add to the listbox
            History.Items.Add(msg);

            //add to the file
            updateFile(msg);
        }

        private void calcFilePath()
        {
            //put this inside a try/catch because we may get into a situation where the user isn't allowed access to this file 
            //(Windows permissions, especially in a corporate environment, can be very restrictive)
            //depending on your specific requirements, you may chose to tell the user that you cannot log
            //and exit the application or, as in this case, silently fail and just not log anything. It depends
            //on your specific circumstances.
            try
            {
                //get the path to the special AppData folder for the current user
                var path = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                //add in our app's directory 
                path = Path.Combine(path, DIRNAME);
                //if it doesn't already exist, create it
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);

                //now add in the filename and save that whole thing to the global
                filePath = Path.Combine(path, FILENAME);
            }
            catch { }
        }

        private void updateFile(string text)
        {
            //if something is wrong, we just don't log the data
            try
            {
                //if something went wrong with permissions, we may not have a valid filePath
                //make sure it is something before we try to use it
                if (!string.IsNullOrEmpty(filePath))
                    //note the linebreak character being added. If not, then all the events end up
                    //on the same line in the file
                    File.AppendAllText(filePath, $"{text}\n");
            }
            catch { }
        }
    }
}
