﻿using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;

namespace BackgroundWorkerSample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        VM vm = new VM();
        public MainWindow()
        {
            InitializeComponent();
            DataContext = vm;
        }

        private void start_Click(object sender, RoutedEventArgs e)
        {
            vm.StartCalc();
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            vm.CancelCalc();
        }

        private void message_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("This is a message that can be shown while the background task is running");
        }

        private void textBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            var r = new Regex(@"[\d\.]");
            e.Handled = !r.IsMatch(e.Text);
        }
    }
}
