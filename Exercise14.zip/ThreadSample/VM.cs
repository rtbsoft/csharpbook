﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Windows.Threading;

namespace ThreadSample
{
    internal class VM : BindingObject
    {
        private ThreadObject bkgThread;
        private readonly Dispatcher dispatcher = Dispatcher.CurrentDispatcher;

        #region properties
        private int progressPct;
        public int ProgressPct { get => progressPct; set => SetField(ref progressPct, value); }

        //this started out as a single text value to the displayed, but as things have got more complex 
        //it may now be time to make this a list of some class
        //at this point, the text put here has two values (largest prime and duration), but we'd probably
        //also want to know whether the user canceled or not, and if they did, then how far did we get with 
        //testing before aborting. That's two more values... and probably time to make it a class
        //and then change the XAML to display the values properly.
        public BindingList<string> Values { get; set; } = new BindingList<string>();

        private bool isComplete;
        public bool IsComplete { get => isComplete; set => SetField(ref isComplete, value); }

        private int maxNumber;
        public int MaxNumber { get => maxNumber; set => SetField(ref maxNumber, value); }
        #endregion
        #region methods
        public void StartCalc()
        {
            if (bkgThread == null)
            {
                //get the UI back in starting mode
                IsComplete = false;
                ProgressPct = 0;

                //create a new background worker 
                bkgThread = new ThreadObject
                {
                    DoWork = getPrimes
                };
                bkgThread.Run(maxNumber);
            }
        }

        public void CancelCalc() => bkgThread.Cancel();

        private void onPrimesCompleted(List<int> primes, TimeSpan elapsed)
        {
            //if we have some primes, report our results
            //note the ^1 syntax - it means the last element of the collection
            if (primes.Count > 0)
            {
                var value = primes[^1];

                dispatcher.BeginInvoke(new Action(() =>
                {
                    //dump the info
                    Values.Add($"Largest prime under {maxNumber:n0} is {value:n0} found in {elapsed.TotalMilliseconds:n0} msec");
                    //reset things
                    IsComplete = true;
                    bkgThread = null;
                }));
            }
        }

        private void checkProgress(double scale, int numberToCheck, ref int prevProgress)
        {
            //calculate a progress integer (0-100) 
            var curProgress = (int)(scale * numberToCheck);
            //and only if it is different from the last progress we reported
            if (curProgress != prevProgress)
            {
                //report new progress
                dispatcher.BeginInvoke(new Action(() => ProgressPct = curProgress), null);
                prevProgress = curProgress;
            }
            //do not report progress each time through the loop, or the UI thread will be overwhelmed
            //and the UI will appear to stall
        }

        private bool checkPrime(int numberToCheck, List<int> primes)
        {
            //assume the number is a prime
            var isPrime = true;

            //we only need to check factors up to the sqrt of the number
            var maxPrime = Math.Sqrt(numberToCheck);
            //we only need to check to see if the primes are factors
            for (var i = 0; i < primes.Count && primes[i] <= maxPrime; i++)
            {
                //if there's no remainder from the division
                if (numberToCheck % primes[i] == 0)
                {
                    //this is not a prime, so we're out
                    isPrime = false;
                    break;
                }
            }

            return isPrime;
        }

        private void getPrimes(object o)
        {
            //extract the passed argument
            var max = o as int? ?? 0;
            //figure out how many steps makes 1% progress
            var scale = 100.0 / max;

            //store the primes we've found so far
            //another optimization would be to remember this between runs so if the user
            //picks a smaller max number later, we can just look up the answer instead of recalculating
            //but, if we did that, then the point of this long running background thread demo might be lost :)
            var primes = new List<int>();
            //keep track of what progress we've reported so far
            var prevProgress = 0;

            //start a timer
            var stopwatch = new Stopwatch();
            stopwatch.Start();

            //check all the numbers up to the user's max to see it they are prime
            for (var numberToCheck = 2; numberToCheck < max + 1; numberToCheck++)
            {
                //did the user want to cancel? get out now
                if (bkgThread.IsCancelRequested)
                    break;

                if (checkPrime(numberToCheck, primes))
                    primes.Add(numberToCheck);

                checkProgress(scale, numberToCheck, ref prevProgress);
            }

            //stop the timer
            stopwatch.Stop();

            onPrimesCompleted(primes, stopwatch.Elapsed);
        }
        #endregion
    }
}
