﻿using System;
using System.Threading;

namespace ThreadSample
{
    internal class ThreadObject
    {
        private Thread worker;

        public Action<object> DoWork { get; set; }

        public bool IsCancelRequested { get; private set; }

        public void Run(object o)
        {
            if (worker == null || worker.ThreadState != ThreadState.Running)
            {
                //create a new background worker 
                worker = new Thread(worker_DoWork);
                worker.Start(o);
            }
        }

        public void Cancel()
        {
            IsCancelRequested = true;
        }

        private void worker_DoWork(object o)
        {
            DoWork(o);
        }
    }
}
