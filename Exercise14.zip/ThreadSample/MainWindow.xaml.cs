﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ThreadSample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        VM vm = new VM();
        public MainWindow()
        {
            InitializeComponent();
            DataContext = vm;
        }

        private void start_Click(object sender, RoutedEventArgs e)
        {
            vm.StartCalc();
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            vm.CancelCalc();
        }

        private void message_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("This is a message that can be shown while the background task is running");
        }

        private void textBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            var r = new Regex(@"[\d\.]");
            e.Handled = !r.IsMatch(e.Text);
        }
    }
}
