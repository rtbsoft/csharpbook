﻿using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AwaitSample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string text1 = File.ReadAllText("filePath");
            //string text2 = await File.ReadAllTextAsync("filePath");
            //string[] lines = text2.Split('\n');
            string text2 = File.ReadAllTextAsync("filePath").Result;
        }

        public static async Task<string> ReadAllTextAsync(string filePath)
        {
            using var fileStream = File.OpenRead(filePath);
            using var streamReader = new StreamReader(fileStream);
            var stringBuilder = new StringBuilder();

            string line;
            for (;;)
            {
                if ((line = await streamReader.ReadLineAsync()) == null)
                    break;
                stringBuilder.AppendLine(line);
            }

            return stringBuilder.ToString();
        }
    }
}
