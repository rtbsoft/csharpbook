﻿using NorthWindOrders.Models;
using NorthWindOrders.ViewModels;

using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace NorthWindOrders
{
    /// <summary>
    /// Interaction logic for OrderEditWindow.xaml
    /// </summary>
    public partial class OrderEditWindow : Window
    {
        //provide feedback to caller as to the state of the result
        public bool? Result { get; private set; }

        private readonly Order o;
        private readonly List<OrderDetail> ods;
        private readonly OrderVM ovm = OrderVM.Inst;

        public OrderEditWindow(Order o = null)
        {
            InitializeComponent();

            //if we received no order, then create a new one for adding
            //if did receive one, then make a copy of it to edit (so we can cancel)
            this.o = o == null ? new Order() : o.Clone();

            //depend on the OrderVM keeping the OrderDetails BindingList up to date with the currently selected order
            //also depend that if there is not a selected order, this list will be empty
            //however, if there is a selected order and the user still presses Add, we don't need to make copies
            ods = new List<OrderDetail>();
            if (o != null)
                foreach (var od in ovm.OrderDetails)
                    //clone each of the detail objects so we can cancel and also tell what's new/edited/deleted
                    ods.Add(od.Clone());

            //the data context for this XAML will also contain the main VM
            //since the main VM has the list of companies, suppliers, products, and employees
            //in this case, we want to have the Details BindingList and the ods list mirror each other's changes
            var oevm = new OrderEditVM
            {
                Order = this.o,
                OrderDetail = new OrderDetail(),
                Details = new BindingList<OrderDetail>(ods),
                OrderVM = ovm
            };
            //we also want to be notified of changes to properties
            //anyone can listen, not just XAML code
            oevm.PropertyChanged += oevm_PropertyChanged;

            DataContext = oevm;
        }

        private void oevm_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            //whenever the OrderDetail property changes
            if (e.PropertyName == "OrderDetail")
            {
                //manually resize all the columns of the table so if the new one is longer, all columns expand
                foreach(var c in (ProductListView.View as GridView).Columns)
                {
                    //NaN means auto width, so we temporarily set each column to its actual width and then back to auto
                    if (double.IsNaN(c.Width))
                        c.Width = c.ActualWidth;
                    c.Width = double.NaN;
                }
            }
        }

        //user wants to add a product
        private void addProduct_Click(object sender, RoutedEventArgs e)
        {
            var evm = DataContext as OrderEditVM;

            //if this is a valid new product
            if (evm.OrderDetail.ProductId != 0 &&
                evm.Details.All(d => d.ProductId != evm.OrderDetail.ProductId) &&
                evm.OrderDetail.Quantity > 0)
            {
                //update the rest of it
                evm.OrderDetail.UnitPrice = ovm.Products.FirstOrDefault(p => p.Id == evm.OrderDetail.ProductId)?.UnitPrice ?? 0;
                evm.OrderDetail.OrderId = o.Id;
                evm.Details.Add(evm.OrderDetail);
                //put a new one in its place (clears out the UI)
                evm.OrderDetail = new OrderDetail();
            }
        }

        //user wants to 'save'
        //since the user is editing the currently selected detail, it is already saved
        //but we'll replace it with a new OrderDetail so no further changes can happen to it
        private void saveProduct_Click(object sender, RoutedEventArgs e)
        {
            //replace the one just modified with an empty one
            var evm = DataContext as OrderEditVM;
            evm.OrderDetail = new OrderDetail();
        }

        //user wants to delete
        private void deleteProduct_Click(object sender, RoutedEventArgs e)
        {
            //remove the current selection from Details
            var evm = DataContext as OrderEditVM;
            evm.Details.Remove(evm.OrderDetail);
            evm.OrderDetail = new OrderDetail();
        }

        private void save_Click(object sender, RoutedEventArgs e)
        {
            //we return true or false, depending on whether the add/update to the database worked or not
            Result = ovm.AddOrUpdateOrder(o, ods);
            Close();
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            //return null to indicate that the user canceled and no action should be taken
            Result = null;
            Close();
        }
    }
}
