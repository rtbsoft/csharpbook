﻿using NorthWindOrders.ViewModels;

using System;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace NorthWindOrders.Converters
{
    public class ProductIdToProductName : IValueConverter
    {
        //see CustomerIdToCustomer for a full discussion of why this is here
        private readonly OrderVM vm = OrderVM.Inst;

        //extract the name from the Product object referenced by the Id given
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var name = "";

            if (value is int productId)
                name = vm.Products.FirstOrDefault(p => p.Id == productId)?.Name;

            return name;
        }

        //this converter is used in a display only field, so no return conversion is necessary
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
    }
}
