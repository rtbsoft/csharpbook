﻿using NorthWindOrders.Models;
using NorthWindOrders.ViewModels;

using System;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace NorthWindOrders.Converters
{
    public class ProductIdToProduct : IValueConverter
    {
        //see CustomerIdToCustomer for a full discussion of why this is here
        private readonly OrderVM vm = OrderVM.Inst;

        //the combobox is provided a list of Product objects, but the OrderDetail object only has the product's Id
        //so we need to convert from the Id to the whole object 
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Product p = null;

            if (value is int productId)
                p = vm.Products.FirstOrDefault(p => p.Id == productId);

            return p;
        }

        //when the user changes the selection in the combobox, they are selecting new Product object
        //so we need to convert from the whole object to the Id for updating the OrderDetail object's field
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) 
            => (value as Product)?.Id;
    }
}
