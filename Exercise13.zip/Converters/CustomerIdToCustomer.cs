﻿using NorthWindOrders.Models;
using NorthWindOrders.ViewModels;

using System;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace NorthWindOrders.Converters
{
    public class CustomerIdToCustomer : IValueConverter
    {
        //we have the list of customers in the OrderVM, so we'll grab an instance of the class
        //doing this exposes this class to a lot of things it doesn't need to know about
        //and we could get our own copy from the database, but then we'd be responsible for keeping
        //it up to date if others are also working with this database
        //we could also create separate VM classes for the 'reference' data but that seems like unnecessary
        //complexity for now
        private readonly OrderVM vm = OrderVM.Inst;

        //the combobox is provided a list of customer objects, but the order object only has the customer's Id
        //so we need to convert from the Id to the whole object 
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Customer c = null;

            if (value is string customerId)
                c = vm.Customers.FirstOrDefault(c => c.Id == customerId);

            return c;
        }

        //when the user changes the selection in the combobox, they are selecting new customer object
        //so we need to convert from the whole object to the Id for updating the Order object's field
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) 
            => (value as Customer)?.Id;
    }
}
