﻿using System.Collections.Generic;

namespace NorthWindOrders.Models
{
    //inherit from BindingObject so we can notify XAML when something changes in the object
    //when it is on its own or in a BindingList
    internal class OrderDetail : BindingObject
    {
        private int orderId;
        public int OrderId { get => orderId; set => SetField(ref orderId, value); }

        private int productId;
        public int ProductId { get => productId; set => SetField(ref productId, value); }

        private decimal unitPrice;
        public decimal UnitPrice
        {
            get => unitPrice;
            set { if (SetField(ref unitPrice, value)) OnPropertyChanged(nameof(Total)); }
        }

        private int quantity;
        public int Quantity
        {
            get => quantity;
            set { if (SetField(ref quantity, value)) OnPropertyChanged(nameof(Total)); }
        }

        private decimal discount;
        public decimal Discount
        {
            get => discount;
            set { if (SetField(ref discount, value)) OnPropertyChanged(nameof(Total)); }
        }

        //do the calculation for Total, so it isn't scattered about our code
        public decimal Total => UnitPrice * Quantity * (1 - Discount);

        //make a copy of this object
        //note this is only a shallow copy, but we only have simple properties, so that's ok
        public OrderDetail Clone() => (OrderDetail)MemberwiseClone();
    }

    //custom equality class for use by Linq functions
    internal class OrderDetailEqualityComparer : IEqualityComparer<OrderDetail>
    {
        public bool Equals(OrderDetail od1, OrderDetail od2)
            => od2 == null && od1 == null ||
               od1 != null && od2 != null &&
               od1.OrderId == od2.OrderId && od1.ProductId == od2.ProductId;

        public int GetHashCode(OrderDetail od)
        {
            var hCode = od.OrderId ^ od.ProductId;
            return hCode.GetHashCode();
        }
    }
}
