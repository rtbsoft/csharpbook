﻿namespace NorthWindOrders.Models
{
    //the shipper table has many more fields, but these are all we need in this application
    internal class Shipper
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
