﻿namespace NorthWindOrders.Models
{
    internal class Employee
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }

        //calculate a 'full name' for sorting and display
        //in all cases, we could have replaced this with more complex code whereever this is used
        //but the effort required to avoid this field would be significantly more work
        public string FullName { get => $"{FirstName} {LastName}"; }
    }
}
