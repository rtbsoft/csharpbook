﻿using NorthWindOrders.Models;

using System.Collections.Generic;

namespace NorthWindOrders.Repository
{
    //encapsulate the methods required for CRUD operations to the Employee table
    //add other methods as required
    //this may seem like overkill to have a separate class, but an application may have a hundred or more tables
    //all with all four operations -- putting them in one file results in a monster class that is difficult to
    //operate with. Start with this pattern and you will not need to refactor as the application grows.
    internal static class EmployeeRepository
    {
        private const string SQL_SELECT_EMPLOYEES = "SELECT * FROM Employees";

        internal static List<Employee> GetEmployees() => Db.Inst.GetItems(SQL_SELECT_EMPLOYEES, dr => new Employee
        {
            Id = Db.GetDbInt(dr, "EmployeeId") ?? 0,
            FirstName = Db.GetDbString(dr, "FirstName"),
            LastName = Db.GetDbString(dr, "LastName"),
            Title = Db.GetDbString(dr, "Title"),
        });
    }
}
