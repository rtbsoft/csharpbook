﻿using NorthWindOrders.Models;

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;

namespace NorthWindOrders.Repository
{
    //encapsulate the methods required for CRUD operations to the Order and OrderDetail tables
    //since all the methods are static, we can declare the entire class to be static
    internal static class OrderRepository
    {
        #region SQL statements
        //we are to manipulate orders, so we need all four CRUD operations defined
        //NOTE this query includes a subquery to add a value not normally in the table
        //you can build your sql and C# objects however is convenient
        //you can also create Views and Stored Procedures on the SQL side and execute those here as well
        private const string SQL_SELECT_ORDERS = "SELECT *,(select subtotal from [order subtotals] where OrderID = o.OrderId) Subtotal FROM Orders o";
        private const string SQL_SELECT_ORDERDETAILS = "SELECT * FROM [Order Details] WHERE OrderId = @ORDERID";

        private const string SQL_UPDATE_ORDER = "UPDATE Orders SET " +
            "EmployeeId = @EMPLOYEEID, OrderDate = @ORDERDATE, RequiredDate = @REQUIREDDATE, ShippedDate = @SHIPPEDDATE, " +
            "ShipVia = @SHIPPERID, Freight = @FREIGHT, ShipName = @SHIPNAME, ShipAddress = @SHIPADDRESS, " +
            "ShipCity = @SHIPCITY, ShipRegion = @SHIPREGION, ShipPostalCode = @SHIPPOSTALCODE, ShipCountry = @SHIPCOUNTRY " +
            "WHERE OrderId = @ORDERID";
        private const string SQL_UPDATE_ORDERDETAIL = "UPDATE [Order Details] SET " +
            "UnitPrice = @UNITPRICE, Quantity = @QUANTITY, Discount = @DISCOUNT " +
            "WHERE orderId = @ORDERID AND productId = @PRODUCTID";

        //NOTE the second sql statement in this string. It is possible to have as many statements as desired.
        private const string SQL_INSERT_ORDER = "INSERT INTO Orders " +
            "(CustomerId, EmployeeId, OrderDate, RequiredDate, ShippedDate, ShipVia, Freight, " +
            "ShipName, ShipAddress, ShipCity, ShipRegion, ShipPostalCode, ShipCountry) " +
            "VALUES " +
            "(@CUSTOMERID, @EMPLOYEEID, @ORDERDATE, @REQUIREDDATE, @SHIPPEDDATE, @SHIPPERID, @FREIGHT, " +
            "@SHIPNAME, @SHIPADDRESS, @SHIPCITY, @SHIPREGION, @SHIPPOSTALCODE, @SHIPCOUNTRY); " +
            "SELECT @@IDENTITY";
        private const string SQL_INSERT_ORDERDETAIL = "INSERT INTO [Order Details] " +
            "(OrderId, ProductId, UnitPrice, Quantity, Discount) " +
            "VALUES " +
            "(@ORDERID, @PRODUCTID, @UNITPRICE, @QUANTITY, @DISCOUNT)";

        private const string SQL_DELETE_ORDER = "DELETE FROM Orders WHERE orderId = @ORDERID";
        private const string SQL_DELETE_ORDERDETAILS = "DELETE FROM [Order Details] WHERE orderId = @ORDERID";
        private const string SQL_DELETE_ONE_ORDERDETAIL = "DELETE FROM [Order Details] WHERE orderId = @ORDERID AND productId = @PRODUCTID";
        #endregion
        #region read methods

        //for the most part, try to stick with the database names in the C# object to lessen confusion
        //however, I did change a couple of names: Id for the primary key, and ShipperId instead of ShipVia for a foreign key
        internal static List<Order> GetOrders() => Db.Inst.GetItems(SQL_SELECT_ORDERS, dr => new Order
        {
            Id = Db.GetDbInt(dr, "OrderId") ?? 0,
            CustomerId = Db.GetDbString(dr, "CustomerId"),
            EmployeeId = Db.GetDbInt(dr, "EmployeeId"),
            Freight = Db.GetDbDecimal(dr, "Freight"),
            OrderDate = Db.GetDbDate(dr, "OrderDate"),
            RequiredDate = Db.GetDbDate(dr, "RequiredDate"),
            ShipCity = Db.GetDbString(dr, "ShipCity"),
            ShipAddress = Db.GetDbString(dr, "ShipAddress"),
            ShipCountry = Db.GetDbString(dr, "ShipCountry"),
            ShipName = Db.GetDbString(dr, "ShipName"),
            ShippedDate = Db.GetDbDate(dr, "ShippedDate"),
            ShipperId = Db.GetDbInt(dr, "ShipVia"),
            ShipPostalCode = Db.GetDbString(dr, "ShipPostalCode"),
            ShipRegion = Db.GetDbString(dr, "ShipRegion"),
            Subtotal = Db.GetDbDecimal(dr, "Subtotal"),
        });

        //in this case, we only want to get those order details associated with the current order
        //so we take advantage of the second parameter to specify a condition
        internal static List<OrderDetail> GetOrderDetails(int orderId) => Db.Inst.GetItems(SQL_SELECT_ORDERDETAILS, dr => new OrderDetail
        {
            Discount = (decimal)(Db.GetDbFloat(dr, "Discount") ?? 0),
            OrderId = Db.GetDbInt(dr, "OrderId") ?? 0,
            ProductId = Db.GetDbInt(dr, "ProductId") ?? 0,
            Quantity = Db.GetDbInt16(dr, "Quantity") ?? 0,
            UnitPrice = Db.GetDbDecimal(dr, "UnitPrice") ?? 0,
        }, new SqlParameter
        {
            ParameterName = "@ORDERID",
            DbType = System.Data.DbType.Int32,
            Value = orderId
        });
        #endregion
        #region insert methods
        //insert a new order and its associated orderDetail objects
        internal static (bool, int) InsertOrder(Order o, List<OrderDetail> ods)
        {
            var success = false;
            var id = 0;
            var db = Db.Inst;

            try
            {
                //create a new instance of SqlCommand
                using var cmdO = db.GetCommand(SQL_INSERT_ORDER, true);
                //add all the fields from the object as parameters to the query
                cmdO.Parameters.AddWithValueNull("@CUSTOMERID", o.CustomerId);
                cmdO.Parameters.AddWithValueNull("@EMPLOYEEID", o.EmployeeId);
                cmdO.Parameters.AddWithValueNull("@FREIGHT", o.Freight);
                cmdO.Parameters.AddWithValueNull("@ORDERDATE", o.OrderDate);
                cmdO.Parameters.AddWithValueNull("@REQUIREDDATE", o.RequiredDate);
                cmdO.Parameters.AddWithValueNull("@SHIPCITY", o.ShipCity);
                cmdO.Parameters.AddWithValueNull("@SHIPADDRESS", o.ShipAddress);
                cmdO.Parameters.AddWithValueNull("@SHIPCOUNTRY", o.ShipCountry);
                cmdO.Parameters.AddWithValueNull("@SHIPNAME", o.ShipName);
                cmdO.Parameters.AddWithValueNull("@SHIPPEDDATE", o.ShippedDate);
                cmdO.Parameters.AddWithValueNull("@SHIPPERID", o.ShipperId);
                cmdO.Parameters.AddWithValueNull("@SHIPPOSTALCODE", o.ShipPostalCode);
                cmdO.Parameters.AddWithValueNull("@SHIPREGION", o.ShipRegion);
                //because the insert has a second @@IDENTITY statement, it will be that statement
                //that returns, so calling ExecuteScalar makes sense here
                //whatever it returns, we want to convert it to an int
                //in this case ExecuteScalar returns a decimal data type, so the other way to do this
                //would be to cast twice (int)(decimal)cmd0.ExecuteScalar()
                //using Convert means that if this were to change in the future, we'd still get our int
                id = Convert.ToInt32(cmdO.ExecuteScalar(), CultureInfo.InvariantCulture);

                //for the order detail list, we separate out the creation of the parameters
                //and the assignment of values to them
                using var cmdD = db.GetCommand(SQL_INSERT_ORDERDETAIL, true);
                cmdD.Parameters.Add(new SqlParameter { ParameterName = "@ORDERID" });
                cmdD.Parameters.Add(new SqlParameter { ParameterName = "@PRODUCTID" });
                cmdD.Parameters.Add(new SqlParameter { ParameterName = "@UNITPRICE" });
                cmdD.Parameters.Add(new SqlParameter { ParameterName = "@QUANTITY" });
                cmdD.Parameters.Add(new SqlParameter { ParameterName = "@DISCOUNT" });

                foreach (var od in ods)
                {
                    cmdD.Parameters["@ORDERID"].Value = id;
                    cmdD.Parameters["@PRODUCTID"].Value = od.ProductId;
                    cmdD.Parameters["@UNITPRICE"].Value = od.UnitPrice;
                    cmdD.Parameters["@QUANTITY"].Value = od.Quantity;
                    cmdD.Parameters["@DISCOUNT"].Value = (float)od.Discount;
                    cmdD.ExecuteNonQuery();
                }

                //if we made it this far, then it all worked so commit the result
                success = id > 0;
                if (success)
                    db.Commit();
                else
                    db.Rollback();
            }
            catch
            {
                db.Rollback();
            }

            return (success, id);
        }

        //when adding an orderdetail object to an existing order, we add them one at a time
        internal static bool InsertOrderDetail(OrderDetail od)
        {
            var success = false;
            var db = Db.Inst;

            try
            {
                using var cmd = db.GetCommand(SQL_INSERT_ORDERDETAIL);
                cmd.Parameters.AddWithValue("@ORDERID", od.OrderId);
                cmd.Parameters.AddWithValue("@PRODUCTID", od.ProductId);
                cmd.Parameters.AddWithValue("@UNITPRICE", od.UnitPrice);
                cmd.Parameters.AddWithValue("@QUANTITY", od.Quantity);
                cmd.Parameters.AddWithValue("@DISCOUNT", od.Discount);
                success = cmd.ExecuteNonQuery() > 0;
            }
            catch { }

            return success;
        }
        #endregion
        #region update methods
        //
        internal static bool UpdateOrder(Order o, List<OrderDetail> odsDelete, List<OrderDetail> odsInsert, List<OrderDetail> odsUpdate)
        {
            var success = false;
            var db = Db.Inst;

            try
            {
                //update the order
                using var cmdO = db.GetCommand(SQL_UPDATE_ORDER, true);
                cmdO.Parameters.AddWithValueNull("@ORDERID", o.Id);
                cmdO.Parameters.AddWithValueNull("@CUSTOMERID", o.CustomerId);
                cmdO.Parameters.AddWithValueNull("@EMPLOYEEID", o.EmployeeId);
                cmdO.Parameters.AddWithValueNull("@FREIGHT", o.Freight);
                cmdO.Parameters.AddWithValueNull("@ORDERDATE", o.OrderDate);
                cmdO.Parameters.AddWithValueNull("@REQUIREDDATE", o.RequiredDate);
                cmdO.Parameters.AddWithValueNull("@SHIPCITY", o.ShipCity);
                cmdO.Parameters.AddWithValueNull("@SHIPADDRESS", o.ShipAddress);
                cmdO.Parameters.AddWithValueNull("@SHIPCOUNTRY", o.ShipCountry);
                cmdO.Parameters.AddWithValueNull("@SHIPNAME", o.ShipName);
                cmdO.Parameters.AddWithValueNull("@SHIPPEDDATE", o.ShippedDate);
                cmdO.Parameters.AddWithValueNull("@SHIPPERID", o.ShipperId);
                cmdO.Parameters.AddWithValueNull("@SHIPPOSTALCODE", o.ShipPostalCode);
                cmdO.Parameters.AddWithValueNull("@SHIPREGION", o.ShipRegion);
                success = cmdO.ExecuteNonQuery() > 0;

                //for orderdetail updating, we have three steps: insert, delete, and update
                //we could, of course, delete all the old and replace them with new, but with an
                //auto incrementing primary key field, the number would quickly and artificially climb
                //if we were to add timestamp fields into the database (deletedAt, createdAt, updatedAt)
                //then these also would be meaningless if we kept deleting and creating the same detail record
                //repeatedly because some other record for that order had changed.

                //create a single SQL command to do all three
                using var cmdD = db.GetCommand(true);
                //initialize the two parameters required for deleting
                cmdD.Parameters.Add(new SqlParameter { ParameterName = "@ORDERID" });
                cmdD.Parameters.Add(new SqlParameter { ParameterName = "@PRODUCTID" });

                //and delete as many as necessary
                cmdD.CommandText = SQL_DELETE_ONE_ORDERDETAIL;
                foreach (var od in odsDelete)
                {
                    cmdD.Parameters["@ORDERID"].Value = od.OrderId;
                    cmdD.Parameters["@PRODUCTID"].Value = od.ProductId;
                    success &= cmdD.ExecuteNonQuery() > 0;
                }

                //now add the remaining parameters
                //we could not add these at first because delete does not require them
                //and if we didn't provide values, C# complains even though the parameters are not used
                cmdD.Parameters.Add(new SqlParameter { ParameterName = "@UNITPRICE" });
                cmdD.Parameters.Add(new SqlParameter { ParameterName = "@QUANTITY" });
                cmdD.Parameters.Add(new SqlParameter { ParameterName = "@DISCOUNT" });

                //change the sql statement and insert as many as necessary
                cmdD.CommandText = SQL_INSERT_ORDERDETAIL;
                foreach (var od in odsInsert)
                {
                    cmdD.Parameters["@ORDERID"].Value = o.Id;
                    cmdD.Parameters["@PRODUCTID"].Value = od.ProductId;
                    cmdD.Parameters["@UNITPRICE"].Value = od.UnitPrice;
                    cmdD.Parameters["@QUANTITY"].Value = od.Quantity;
                    cmdD.Parameters["@DISCOUNT"].Value = (float)od.Discount;
                    success &= cmdD.ExecuteNonQuery() > 0;
                }

                //finally change the sql statement again and update as many as necessary
                cmdD.CommandText = SQL_UPDATE_ORDERDETAIL;
                foreach (var od in odsUpdate)
                {
                    cmdD.Parameters["@ORDERID"].Value = od.OrderId;
                    cmdD.Parameters["@PRODUCTID"].Value = od.ProductId;
                    cmdD.Parameters["@UNITPRICE"].Value = od.UnitPrice;
                    cmdD.Parameters["@QUANTITY"].Value = od.Quantity;
                    cmdD.Parameters["@DISCOUNT"].Value = (float)od.Discount;
                    success &= cmdD.ExecuteNonQuery() > 0;
                }

                if (success)
                    db.Commit();
                else
                    db.Rollback();
            }
            catch
            {
                db.Rollback();
            }

            return success;
        }
        #endregion
        #region delete methods
        //if we are deleting the order, then also delete any detail items associated with that order
        //we will return success as long as no exception is thrown even if we ended up not deleting anything
        //The idea is that if our user tries to delete something that's already deleted in the database, then we should still
        //remove it from our local lists.
        internal static bool DeleteOrder(Order o)
        {
            var success = true;
            var db = Db.Inst;

            try
            {
                using var cmdI = db.GetCommand(SQL_DELETE_ORDERDETAILS, true);
                cmdI.Parameters.AddWithValue("@ORDERID", o.Id);
                cmdI.ExecuteNonQuery();

                using var cmdO = db.GetCommand(SQL_DELETE_ORDER, true);
                cmdO.Parameters.AddWithValue("@ORDERID", o.Id);
                cmdO.ExecuteNonQuery();

                db.Commit();
            }
            catch
            {
                db.Rollback();
                success = false;
            }

            return success;
        }
        #endregion
    }
}
