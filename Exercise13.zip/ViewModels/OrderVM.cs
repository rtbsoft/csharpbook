﻿using NorthWindOrders.Models;
using NorthWindOrders.Repository;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace NorthWindOrders.ViewModels
{
    internal enum SortColumn
    {
        SoldBy,
        SoldTo,
        Ordered,
        Shipped,
        Total
    }

    internal class OrderVM : BindingObject
    {
        #region Private variables
        //repository of all orders in system; kept up to date locally after initial download
        //this assumes only one user of the database can create orders. If not true, then
        //add an expiry time and reload from the database on some schedule. The expiry time would
        //would depend on assumed frequency of order creation. Thousands of orders per day: one minute expiration
        //a handful per day: perhaps 15 or 30 minutes
        private readonly List<Order> allOrders;

        //repository of the current set of orders visible in the UI; since multiple operations can affect this
        //(sorting, filtering, deleting) it is global to the class so it does not have to be recalculated so often
        private List<Order> filteredOrders;

        //keep track of the state of sorting orders
        private SortColumn previousSortColumn = SortColumn.Ordered;
        private bool ascendingSort = true;
        #endregion
        #region Properties
        //reference data
        public BindingList<Customer> Customers { get; set; }
        public BindingList<Employee> Employees { get; set; }
        public BindingList<Product> Products { get; set; }
        public BindingList<Shipper> Shippers { get; set; }

        //Data that may be modified
        public BindingList<Order> Orders { get; set; }
        public BindingList<OrderDetail> OrderDetails { get; set; }

        //selected order information
        private Order selectedOrder;
        public Order SelectedOrder
        {
            get => selectedOrder;
            set
            {
                if (SetField(ref selectedOrder, value))
                {
                    //if the selected order has changed, clear out the old order details
                    //do that here because the selected order may have been cleared
                    OrderDetails.Clear();
                    if (selectedOrder != null)
                    {
                        //if there is a new selected order, then go get its details from the database
                        //we could cache this information locally instead of getting it every time
                        //by adding a dictionary of details and only getting those that are not already
                        //present in the dictionary. We could also get all the details for all orders up front
                        //and cache all of it. Which of the three approaches to take really depends on the 
                        //expected number of details and how often they are reviewed. Most likely, old orders 
                        //are viewed very infrequently, so caching all of them up front doesn't make sense.
                        var details = OrderRepository.GetOrderDetails(selectedOrder.Id);
                        if (details != null)
                        {
                            //if we found them, add them to the BindingList for display
                            var subtotal = 0m;
                            foreach (var d in details)
                            {
                                OrderDetails.Add(d);
                                subtotal += d.Total;
                            }
                            //calculate the subtotal and total values for this order
                            //we could also have just got this from the order object
                            Subtotal = subtotal;
                            Total = subtotal + selectedOrder.Freight ?? 0;
                        }
                    }
                    //notify the XAML that HasSelectedOrder has also changed
                    //since it only has a get defined, there is no other way to do this
                    OnPropertyChanged(nameof(HasSelectedOrder));
                }
            }
        }
        //we want to share this information with the XAML
        //we could also have used a converter (SelectedOrderToBooleanConverter)
        //to create the same result, but sometimes going this way is easier....
        public bool HasSelectedOrder { get => SelectedOrder != null; }

        private decimal subtotal;
        public decimal Subtotal { get => subtotal; set => SetField(ref subtotal, value); }

        private decimal total;
        public decimal Total { get => total; set => SetField(ref total, value); }

        //filter values
        private Customer filterSelectedCustomer;
        public Customer FilterSelectedCustomer { get => filterSelectedCustomer; set => SetField(ref filterSelectedCustomer, value); }

        private Employee filterSelectedEmployee;
        public Employee FilterSelectedEmployee { get => filterSelectedEmployee; set => SetField(ref filterSelectedEmployee, value); }

        //use nullable types so if nothing is selected, it displays a blank instead of zeros
        private decimal? filterMinTotal;
        public decimal? FilterMinTotal { get => filterMinTotal; set => SetField(ref filterMinTotal, value); }

        private decimal? filterMaxTotal;
        public decimal? FilterMaxTotal { get => filterMaxTotal; set => SetField(ref filterMaxTotal, value); }

        private DateTime? filterMinDate;
        public DateTime? FilterMinDate { get => filterMinDate; set => SetField(ref filterMinDate, value); }

        private DateTime? filterMaxDate;
        public DateTime? FilterMaxDate { get => filterMaxDate; set => SetField(ref filterMaxDate, value); }

        private bool filterUnshippedOnly;
        public bool FilterUnshippedOnly { get => filterUnshippedOnly; set => SetField(ref filterUnshippedOnly, value); }
        #endregion
        #region Methods

        //name the various sort methods 
        private object orderByEmployee(Order o) => Employees.FirstOrDefault(e => e.Id == o.EmployeeId)?.FullName;
        private object orderByCustomer(Order o) => Customers.FirstOrDefault(c => c.Id == o.CustomerId)?.CompanyName;
        private object orderByOrderDate(Order o) => o.OrderDate;
        private object orderByShippedDate(Order o) => o.ShippedDate;
        private object orderByTotal(Order o) => o.Total;

        //return the sort method that matches the column selected
        private Func<Order, object> getSortFn(SortColumn column) => column switch
        {
            SortColumn.SoldBy => orderByEmployee,
            SortColumn.SoldTo => orderByCustomer,
            SortColumn.Ordered => orderByOrderDate,
            SortColumn.Shipped => orderByShippedDate,
            SortColumn.Total => orderByTotal,
            _ => orderByTotal,
        };

        //the Orders BindingList cannot be deleted and a new one created because the XAML will
        //no longer be aware of changes. So, we keep the original BindingList for the duration
        //and continually clear and reload items individually. The XAML will notice this and update the UI.
        private void loadOrders()
        {
            Orders.Clear();
            foreach (var o in filteredOrders)
                Orders.Add(o);
        }

        //sort on the selected column
        public void SortOrders(SortColumn sortColumn)
        {
            //if the user selected the same column again, reverse the sort order
            if (previousSortColumn == sortColumn)
                ascendingSort = !ascendingSort;
            //otherwise, sort ascending on the new column
            else
            {
                previousSortColumn = sortColumn;
                ascendingSort = true;
            }

            //apply the sort function that matches the column selected and reload the items in the new order
            //use the filtered list of orders since the user may have applied a filter
            var sortFn = getSortFn(sortColumn);
            filteredOrders = (ascendingSort ? filteredOrders.OrderBy(sortFn) : filteredOrders.OrderByDescending(sortFn)).ToList();
            loadOrders();
        }

        //filter the Orders list, reapplying any sort
        public void ApplyFilterAndSort()
        {
            //reapply all filters to the full list of orders
            //note that we don't need to do a .ToList() at this step - saving some processing time
            //rather than multiple .Where() chained calls, it could have been done in one compound condition
            //although that might be faster, this is arguably more readable and modifyable
            var filtered = allOrders.Where(c => filterSelectedCustomer == null || c.CustomerId == filterSelectedCustomer.Id)
                                 .Where(e => filterSelectedEmployee == null || e.EmployeeId == filterSelectedEmployee.Id)
                                 .Where(tn => filterMinTotal == null || tn.Total >= filterMinTotal)
                                 .Where(tx => filterMaxTotal == null || tx.Total <= filterMaxTotal)
                                 .Where(dn => filterMinDate == null || dn.OrderDate >= filterMinDate)
                                 .Where(dx => filterMaxDate == null || dx.OrderDate <= filterMaxDate)
                                 .Where(uo => !filterUnshippedOnly || uo.ShippedDate == null);

            //re-sort based on the last sort column and reload the BindingList
            var sortFn = getSortFn(previousSortColumn);
            filteredOrders = (ascendingSort ? filtered.OrderBy(sortFn) : filtered.OrderByDescending(sortFn)).ToList();
            loadOrders();
        }

        //remove all filtering and resort
        public void ClearFilter()
        {
            FilterMaxTotal = null;
            FilterMinDate = null;
            FilterMinTotal = null;
            FilterMaxDate = null;
            FilterUnshippedOnly = false;
            FilterSelectedCustomer = null;
            FilterSelectedEmployee = null;

            ApplyFilterAndSort();
        }

        //user wants to delete an order
        //provide feedback via the boolean so the UI may notify the user
        //we could also have set a public property but then we'd have to reset that property at some point
        //returning a boolean is easier to manage since its value is transient
        public bool DeleteOrder()
        {
            //attempt to remove it from the database
            var isDeleted = OrderRepository.DeleteOrder(SelectedOrder);

            //if that worked, remove it from all the local lists
            //deleting will not affect the sort order or filtering so
            //no need to refilter or resort
            if (isDeleted)
            {
                //by default, Remove will only find a match if it is exactly the same object
                //because we override the Equals method in the Order object to find it equal if the id matches
                //then SelectedOrder could be a copy of the order object and it would still be removed
                allOrders.Remove(SelectedOrder);
                Orders.Remove(SelectedOrder);
                filteredOrders.Remove(SelectedOrder);

                //ensure we no longer have a local copy of that order
                SelectedOrder = null;
            }

            return isDeleted;
        }

        //save changes to order and order details to database and update UI to match
        public bool AddOrUpdateOrder(Order o, List<OrderDetail> ods)
        {
            var isUpdated = true;

            //if the Id is zero, this is a new order
            if (o.Id == 0)
            {
                //try to add the order to the database
                var (success, id) = OrderRepository.InsertOrder(o, ods);
                if (success)
                {
                    //if that worked, update the id field 
                    o.Id = id;
                    //also update the subtotal, because on startup, we get this via the sql response
                    //but for new orders, we're not going to have it yet
                    o.Subtotal = ods.Sum(od => od.Total);
                    //update our local copy of the full list
                    allOrders.Add(o);
                    //filter and sort, so the new order ends up in the right spot given the current filter and sort
                    ApplyFilterAndSort();
                }
                else
                    isUpdated = false;
            }
            //this order already has an Id, so this must be an update
            else
            {
                //we want to use the Linq set methods to find the differences between the old orderdetails
                //and the post-edit version. We can't use the default equality method for the class because
                //that assumes we'll have the same objects in both lists. We won't in this case because
                //we've created copies to edit. So, we need to override the default.
                var odeq = new OrderDetailEqualityComparer();

                //ods contains the new list
                //for those in ods that are missing from OrderDetails, they are new
                var odsInsert = ods.Except(OrderDetails, odeq).ToList();

                //OrderDetails contains the original list
                //for those in OrderDetails that are missing from ods, they are to be deleted
                var odsDelete = OrderDetails.Except(ods, odeq).ToList();

                //for those in both, compare bodies to find if they are different and update
                var odsUpdate = new List<OrderDetail>();
                //find the ids of all items in both lists
                //the primary key for this table is a compound key (OrderId + ProductId)
                //we can assume that the orderId is unchanging, so the indicator of equality is just the product id
                var productIds = ods.Intersect(OrderDetails, odeq).Select(od => od.ProductId).ToList();
                foreach (var pid in productIds)
                {
                    //get the old and new
                    var odNew = ods.FirstOrDefault(d => d.ProductId == pid);
                    var odOld = OrderDetails.FirstOrDefault(d => d.ProductId == pid);
                    //if there's a difference, add the new item to the list to update
                    if (odNew.Quantity != odOld.Quantity || odNew.UnitPrice != odOld.UnitPrice || odNew.Discount != odOld.Discount)
                        odsUpdate.Add(odNew);
                }

                //attempt to update in the database
                if (OrderRepository.UpdateOrder(o, odsDelete, odsInsert, odsUpdate))
                {
                    //remove the old one and add the new one
                    allOrders.Remove(o);
                    o.Subtotal = ods.Sum(od => od.Total);
                    allOrders.Add(o);

                    //reapply sorting and filtering
                    //we could have been more precise here and found the index of the old item
                    //in the lists and done a RemoveAt/Insert sequence. But I would only do this
                    //if this step is painfully slow.
                    ApplyFilterAndSort();
                }
                else
                    isUpdated = false;
            }

            return isUpdated;
        }
        #endregion
        #region Constructor
        private static OrderVM ovm;
        public static OrderVM Inst => ovm ??= new OrderVM();
        private OrderVM()
        {
            //go get the reference data
            //this app does not change any of these, so they are download once only
            //if there were other apps that could change these in this database, then you would want to 
            //set up a refresh cycle of some kind
            //since they are all displayed in some way, we're going to be nice and sort them
            //into a reasonable order
            Customers = new BindingList<Customer>(CustomerRepository.GetCustomers().OrderBy(c => c.CompanyName).ToList());
            Employees = new BindingList<Employee>(EmployeeRepository.GetEmployees().OrderBy(e => e.FullName).ToList());
            Products = new BindingList<Product>(ProductRepository.GetProducts().OrderBy(p => p.Name).ToList());
            Shippers = new BindingList<Shipper>(ShipperRepository.GetShippers().OrderBy(s => s.Name).ToList());

            //do not initialize the BindingList by passing the allOrders List to it in the constructor
            //because they become linked and any changes to Orders (including sorting and filtering) also affects allOrders
            Orders = new BindingList<Order>();
            OrderDetails = new BindingList<OrderDetail>();

            //apply any initial filtering/sorting after downloading orders from database
            filteredOrders = allOrders = OrderRepository.GetOrders();
            ApplyFilterAndSort();
        }
        #endregion
    }
}
