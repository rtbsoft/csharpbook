﻿using NorthWindOrders.Models;

using System.ComponentModel;

namespace NorthWindOrders.ViewModels
{
    //we need to bind to several things in the OrderEdit XAML
    //we could have added these directly to the OrderVM
    //but by doing it this way, we isolate the special bits only required for editing
    //Not a solid argument either way, but this provides an example of how to incorporate multiple VMs in one XAML.
    internal class OrderEditVM : BindingObject
    {
        private Order order;
        public Order Order { get => order; set => SetField(ref order, value); }

        private OrderDetail orderDetail;
        public OrderDetail OrderDetail { get => orderDetail; set => SetField(ref orderDetail, value); }

        public BindingList<OrderDetail> Details { get; set; }
        public OrderVM OrderVM { get; set; }
    }
}
