﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ArabicToRomanMVVM
{
    internal class VM : INotifyPropertyChanged
    {
        //define constants for the various roman digits
        //makes it easy to switch from upper case to lower case
        //this will also be helpful once we create our own methods
        private const string ONE = "I";
        private const string FIVE = "V";
        private const string TEN = "X";
        private const string FIFTY = "L";
        private const string HUNDRED = "C";
        private const string FIVEHUNDRED = "D";
        private const string THOUSAND = "M";
        private const int MAX_HUNDREDS = 10;

        //the arabic number property that we connect to the XAML
        private int arabicNumber;
        public int ArabicNumber
        {
            get => arabicNumber;
            set
            {
                arabicNumber = value;
                //whenever the number changes, redo the calculation
                calcRomanText();
                notifyChange();
            }
        }

        //the roman text property that we connect to the XAML
        private string romanText;
        public string RomanText
        {
            get => romanText;
            set
            {
                romanText = value;
                notifyChange();
            }
        }

        private string digitToRoman(int digit, string sm, string md, string lg)
        {
            var roman = string.Empty;

            //there's a unique sequence for each possible digit value
            //except zero, because the romans didn't have that concept
            switch (digit)
            {
                case 1:
                    roman += sm;
                    break;
                case 2:
                    roman += sm + sm;
                    break;
                case 3:
                    roman += sm + sm + sm;
                    break;
                case 4:
                    roman += sm + md;
                    break;
                case 5:
                    roman += md;
                    break;
                case 6:
                    roman += md + sm;
                    break;
                case 7:
                    roman += md + sm + sm;
                    break;
                case 8:
                    roman += md + sm + sm + sm;
                    break;
                case 9:
                    roman += sm + lg;
                    break;
            }

            return roman;
        }

        private void calcRomanText()
        {
            //this is where we'll put the result, if we calculated one
            var roman = string.Empty;
            var value = arabicNumber;

            //calculate how many hundreds there are in the value
            //this works because an integer divided by another integer
            //results in an integer. The fractional parts are truncated.
            //For example, 999/100 results in 9
            var hundreds = value / 100;

            //we only allow up to a maximum. If it exceeded, don't try to convert because it won't work
            if (hundreds < MAX_HUNDREDS)
            {
                //if there were any hundreds, then we need to figure out the roman version
                roman += digitToRoman(hundreds, HUNDRED, FIVEHUNDRED, THOUSAND);

                //use mod to get the remainder after division by 100
                value %= 100;
                //repeat the process to figure out how many 10s
                roman += digitToRoman(value / 10, TEN, FIFTY, HUNDRED);

                //use mod to get the remainder after division by 10
                value %= 10;
                //repeat again to figure out how many 1s
                roman += digitToRoman(value, ONE, FIVE, TEN);
            }

            //if the result is an empty string
            if (roman.Length == 0)
                //tell the user what they've typed is invalid
                roman = "Invalid number";

            //set the display
            RomanText = roman;
        }

        #region PropertyChange
        public event PropertyChangedEventHandler PropertyChanged;

        private void notifyChange([CallerMemberName] string propertyName = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        #endregion
    }
}
