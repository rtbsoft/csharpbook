﻿using System.Windows;
using System.Windows.Input;

//Author: Rick Kozak

namespace ArabicToRomanMVVM
{
    public partial class MainWindow : Window
    {
        //create an instance of the VM class
        private readonly VM vm = new VM();

        public MainWindow()
        {
            InitializeComponent();
            //connect the VM class instance to the XAML
            DataContext = vm;
        }

        private void Arabic_KeyDown(object sender, KeyEventArgs e) =>
            //don't allow keystrokes other than numeric keys
            //backspace and arrow keys still work, however
            e.Handled = (e.Key < Key.D0 || e.Key > Key.D9) &&
                        (e.Key < Key.NumPad0 || e.Key > Key.NumPad9);

        private void Arabic_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            //special case
            //we want the roman text to clear when the arabic clears
            //however, since the empty string is not a valid number, we can't do it through VM
            //so we clear it here
            if (string.IsNullOrEmpty(Arabic.Text))
                vm.RomanText = "";
        }
    }
}
